from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
import subprocess,json
root=Path.cwd();p=root/'研究报告/04_word/研究报告终稿.docx'
old=r'F_{\mathrm{new}}\approx\sqrt{3}U_N I_{\mathrm{ref}}\cos\varphi=\sqrt{3}\times10.00\times0.485\times0.95\approx8.00\ \mathrm{MW},'
new=r'''\begin{aligned}
F_{\mathrm{new}}&\approx\sqrt{3}U_N I_{\mathrm{ref}}\cos\varphi\\
&=\sqrt{3}\times10.00\times0.485\times0.95\approx8.00\ \mathrm{MW},
\end{aligned}'''
md=Path('/tmp/link-power-format.md');md.write_text('$$'+new+'$$\n');subprocess.run(['pandoc',str(md),'-o','/tmp/link-power-format.docx'],check=True)
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
q=lambda p,n:'{'+ns[p]+'}'+n
with ZipFile(p) as z:infos=z.infolist();parts={i.filename:z.read(i.filename) for i in infos}
r=E.fromstring(parts['word/document.xml'])
with ZipFile('/tmp/link-power-format.docx') as z:s=E.fromstring(z.read('word/document.xml'))
text=lambda e:''.join(e.xpath('.//m:t/text()|.//w:t/text()',namespaces=ns))
table=next(t for t in r.xpath('.//w:tbl',namespaces=ns) if text(t).endswith('（3-11）') and 'Qsec' in text(t))
e=next(e for e in table.xpath('.//m:mr/m:e',namespaces=ns) if text(e).startswith('Fnew≈'))
for n in list(e):e.remove(n)
for n in s.xpath('.//m:oMath',namespaces=ns)[0]:e.append(deepcopy(n))
# 数值、单位、运算符正体；变量斜体；下标名称正体。
for run in e.xpath('.//m:r',namespaces=ns):
 rp=run.find(q('m','rPr'))
 if rp is None:rp=E.Element(q('m','rPr'));run.insert(0,rp)
 value=''.join(run.xpath('./m:t/text()',namespaces=ns))
 upright=not any(c.isalpha() or '\u0370'<=c<='\u03ff' for c in value) or value in ['new','ref','cos','MW']
 sty=rp.find(q('m','sty'))
 if sty is None:sty=E.SubElement(rp,q('m','sty'))
 sty.set(q('m','val'),'p' if upright else 'i')
 wp=run.find(q('w','rPr'))
 if wp is None:wp=E.SubElement(run,q('w','rPr'))
 f=wp.find(q('w','rFonts'))
 if f is None:f=E.SubElement(wp,q('w','rFonts'))
 for key in ['ascii','hAnsi','cs']:f.set(q('w',key),'Times New Roman')
 f.set(q('w','eastAsia'),'方正仿宋_GBK')
 for key in ['i','iCs']:
  italic=wp.find(q('w',key))
  if italic is None:italic=E.SubElement(wp,q('w',key))
  italic.set(q('w','val'),'0' if upright else '1')
# 保持原三栏、右侧式号及全部其他部件，仅公式宿主显式居中和零缩进。
host=next(e.iterancestors(q('w','p')));pr=host.find(q('w','pPr'))
ind=pr.find(q('w','ind'))
if ind is None:ind=E.SubElement(pr,q('w','ind'))
ind.attrib.clear()
for key in ['left','right','firstLine','hanging','leftChars','rightChars','firstLineChars','hangingChars']:ind.set(q('w',key),'0')
jc=pr.find(q('w','jc'))
if jc is None:jc=E.SubElement(pr,q('w','jc'))
jc.set(q('w','val'),'center')
parts['word/document.xml']=E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(p,'w',ZIP_DEFLATED) as z:
 for info in infos:z.writestr(info,parts[info.filename])
for p in [next((root/'研究报告/03_MD/当前版').glob('03 *.md')),root/'研究报告/03_MD/当前版/研究报告装配稿.md']:
 p.write_text(p.read_text().replace(old,new))
p=root/'研究报告/02图表/当前版/公式/公式清单.json';a=json.loads(p.read_text())
for item in a:item['tex']=item['tex'].replace(old,new)
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
p=root/'研究报告/05_review/当前版/1020联络有功计算说明/本次修改说明.json';a=json.loads(p.read_text());a['公式格式']='长推导在关系符处分两行对齐，保留原生OMML、原三栏居中结构与右侧式号，Times New Roman；变量斜体，数值、单位、函数及文字下标正体。';a['Git']='自动审批因额度限制未能完成，提交未执行。';p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print('公式已在关系符处分两行对齐，保留原生公式及原式号；未运行验证流程。')
