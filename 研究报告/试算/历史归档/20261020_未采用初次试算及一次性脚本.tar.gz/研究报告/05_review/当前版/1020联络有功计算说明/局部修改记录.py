from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
import subprocess,shutil,json,hashlib
root=Path.cwd();out=root/'研究报告/05_review/当前版/1020联络有功计算说明';out.mkdir(exist_ok=True)
word=root/'研究报告/04_word/研究报告终稿.docx';source=next((root/'研究报告/03_MD/当前版').glob('03 *.md'));assembled=root/'研究报告/03_MD/当前版/研究报告装配稿.md';manifest=root/'研究报告/02图表/当前版/公式/公式清单.json'
for p in [word,source,assembled,manifest]:
 q=out/'修改前'/p.relative_to(root);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
old='新增联络的工程计算采用折算后的有功上限8.00 MW。'
new='按三相有功功率关系，以10 kV线电压、485 A允许电流和0.95功率因数折算，有功功率为7.98 MW，新增联络的工程计算上限取8.00 MW。'
old_formula=r'F_{\mathrm{new}}=8.00\ \mathrm{MW},'
new_formula=r'F_{\mathrm{new}}\approx\sqrt{3}U_N I_{\mathrm{ref}}\cos\varphi=\sqrt{3}\times10.00\times0.485\times0.95\approx8.00\ \mathrm{MW},'
old_definition='$F_{\\mathrm{new}}$为新增联络折算后的有功上限，取8.00 MW；'
new_definition='$U_N$为线路线电压，取10.00 kV；$I_{\\mathrm{ref}}$为参考允许电流，取0.485 kA；$\\cos\\varphi$取0.95；$F_{\\mathrm{new}}$为新增联络的工程有功上限，取8.00 MW；'
for p in [source,assembled]:
 s=p.read_text();assert old in s and old_formula in s and old_definition in s
 s=s.replace(old,new).replace(old_formula,new_formula).replace(old_definition,new_definition)
 # 保留用户当前Word中该段的逗号衔接。
 s=s.replace('具体可转功率还受可切换区段负荷限制。墩振线','具体可转功率还受可切换区段负荷限制，墩振线');p.write_text(s)
a=json.loads(manifest.read_text())
for item in a:
 if old_formula in item['tex']:item['tex']=item['tex'].replace(old_formula,new_formula)
manifest.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
# 仅生成本次公式与新增符号，直接写入当前用户保存的Word包。
md=Path('/tmp/link-power-snippet.md');md.write_text('$$'+new_formula+'$$\n\n$U_N$为线路线电压，取10.00 kV；$I_{\\mathrm{ref}}$为参考允许电流，取0.485 kA；$\\cos\\varphi$取0.95；\n')
subprocess.run(['pandoc',str(md),'-o','/tmp/link-power-snippet.docx'],check=True)
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
q=lambda prefix,name:'{'+ns[prefix]+'}'+name
with ZipFile('/tmp/link-power-snippet.docx') as z:snippet=E.fromstring(z.read('word/document.xml'))
with ZipFile(word) as z:infos=z.infolist();parts={i.filename:z.read(i.filename) for i in infos}
r=E.fromstring(parts['word/document.xml'])
def text(p):return ''.join(p.xpath('.//w:t/text()|.//m:t/text()',namespaces=ns))
def replace_text(p,before,after):
 nodes=p.xpath('.//w:t',namespaces=ns);s=''.join(n.text or '' for n in nodes);start=s.index(before);stop=start+len(before);pos=0;done=False
 for n in nodes:
  t=n.text or '';end=pos+len(t)
  if end>start and pos<stop:
   n.text=t[:max(0,start-pos)]+(after if not done else '')+t[max(0,stop-pos):];done=True
  pos=end
paras=r.xpath('.//w:body/w:p',namespaces=ns)
p=next(p for p in paras if old in text(p));replace_text(p,old,new)
table=next(t for t in r.xpath('.//w:tbl',namespaces=ns) if 'Qsec' in text(t) and 'Fnew' in text(t) and len(text(t))<1000)
row=next(e for e in table.xpath('.//m:mr/m:e',namespaces=ns) if text(e).startswith('Fnew='))
math=snippet.xpath('.//m:oMath',namespaces=ns)[0]
for n in list(row):row.remove(n)
for n in math:row.append(deepcopy(n))
# 明确沿用本报告公式字体；变量和数值样式由原生数学对象保留。
def math_fonts(element):
 for run in element.xpath('.//m:r',namespaces=ns):
  rp=run.find(q('w','rPr'))
  if rp is None:rp=E.SubElement(run,q('w','rPr'))
  fonts=rp.find(q('w','rFonts'))
  if fonts is None:fonts=E.SubElement(rp,q('w','rFonts'))
  for key in ['ascii','hAnsi','cs']:fonts.set(q('w',key),'Times New Roman')
  fonts.set(q('w','eastAsia'),'方正仿宋_GBK')
math_fonts(row)
p=next(p for p in paras if text(p).startswith('式中，') and 'Fnew为新增联络折算后的有功上限' in text(p))
replace_text(p,'为新增联络折算后的有功上限，取8.00 MW；','为新增联络的工程有功上限，取8.00 MW；')
f=next(n for n in p if n.tag==q('m','oMath') and text(n)=='Fnew')
defs=snippet.xpath('.//w:body/w:p',namespaces=ns)[1]
run_pr=next(iter(p.xpath('./w:r/w:rPr',namespaces=ns)),None)
idx=list(p).index(f)
for n in defs:
 if n.tag==q('w','pPr'):continue
 n=deepcopy(n)
 if n.tag==q('w','r') and run_pr is not None:
  for oldrp in n.findall(q('w','rPr')):n.remove(oldrp)
  n.insert(0,deepcopy(run_pr))
 math_fonts(n);p.insert(idx,n);idx+=1
parts['word/document.xml']=E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(word,'w',ZIP_DEFLATED) as z:
 for info in infos:z.writestr(info,parts[info.filename])
shutil.copy2(root/'memory/current.md',root/'memory/archive/2026-10-20-联络有功计算说明前.md')
(root/'memory/current.md').write_text('''# 当前工作：补充新增联络有功上限的计算说明

仅在第3.6.2节补充三相有功功率换算：10 kV、485 A、功率因数0.95对应7.98 MW，工程计算采用8.00 MW。对应原生公式及符号解释、六章源和公式清单同步。以用户当前另存的Word为基线，保留其其他文字、格式、公式及批注。

用户明确要求“最简单的修正就好，不需要验证流程了”，本次未执行构建、测试、验证或提交钩子流程。此前三阶段核验记录属于上一版，不作为本次已验证的声明。原始计算与矩阵结果保持。

修改前原件及本次局部处理记录位于研究报告/05_review/当前版/1020联络有功计算说明。
''')
record={'修改':'一处依据说明、对应原生公式和符号解释','计算式':'sqrt(3)×10.00kV×0.485kA×0.95=7.9804240958736MW，工程取值8.00MW','当前Word修改前SHA256':hashlib.sha256((out/'修改前'/word.relative_to(root)).read_bytes()).hexdigest(),'用户要求':'最简单的修正就好，不需要验证流程了','验证流程':'按用户要求未执行','PDF':'未重新导出；当前交付对象为本次直接修改的Word'}
(out/'本次修改说明.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('已局部补充正文、原生公式及符号解释；同步Markdown与公式清单。未执行验证流程。')
