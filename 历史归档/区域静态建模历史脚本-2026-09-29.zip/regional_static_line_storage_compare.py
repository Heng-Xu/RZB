"""2025 年同条件线路与储能/扩容反事实；仅为静态筛选，不替代逐年规划。"""

import json
from pathlib import Path

from . import joint_lifecycle_optimizer as optimizer
from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .regional_revision_run import base_cost_ratios, pizhou_sample_fraction
from .tie_section_audit import transferable_section


OUTPUT = OUTPUT_DIR / "capacity_release_simulation/regional_static_line_compare_2026_09_28"
PIZHOU = ("QX-00005", 110)
LINE_PAIR = ("BDZ-00027", "BDZ-00048")
LINE_KM = 3.0
LINE_CAPACITY_MW = 7.491
OVERHEAD_10K_PER_KM = 24.0
CABLE_10K_PER_KM = 120.0
OVERHEAD_SHARE = .9
SWITCH_10K_EACH = 3.0
SWITCH_COUNT = 2
LINE_UNIT_COST = OVERHEAD_SHARE * OVERHEAD_10K_PER_KM + (1 - OVERHEAD_SHARE) * CABLE_10K_PER_KM
LINE_EXTRA_COST = SWITCH_COUNT * SWITCH_10K_EACH


def run(output_dir: Path = OUTPUT) -> list[dict]:
    output_dir = Path(output_dir)
    original_years = optimizer.YEARS
    optimizer.YEARS = (2025,)
    try:
        baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                    for r in read_csv(OUTPUT_DIR / "planning_2021_common_baseline_stations.csv")}
        _, scenes, durations, peaks, catalog, coefficients = optimizer.load_inputs()
        sample = pizhou_sample_fraction()
        t01_section_mw = transferable_section()["2025_feeder_stress_section_p_seed_mw"]
        t01_fraction = t01_section_mw / sample["sample_current_equivalent_power_mw"]
        cases = (("zero_existing_no_line", 0.0, 0, 0.0),
                 ("zero_existing_one_line", 0.0, 1, 0.0),
                 ("t01_section_no_line", t01_fraction, 0, t01_section_mw),
                 ("t01_section_one_line", t01_fraction, 1, t01_section_mw),
                 ("sample_proxy_no_line", sample["initial_fraction"], 0, sample["sample_transfer_screen_mw"]),
                 ("sample_proxy_one_line", sample["initial_fraction"], 1, sample["sample_transfer_screen_mw"]))
        rows = []
        for name, initial, max_lines, existing_cap in cases:
            station, years, transfers, summary = optimizer.solve_layer(
                PIZHOU, baseline, scenes, durations, peaks, catalog, coefficients,
                optimizer.cost_factors(), 2.0, True,
                line_km=LINE_KM, line_unit_cost=LINE_UNIT_COST,
                line_extra_capex_10k_cny=LINE_EXTRA_COST,
                policy_peak_basis="annual", max_storage_modules=50,
                allow_capacity_release=False, preserve_baseline_forward_margin=True,
                prefer_reserve_at_equal_cost=True, canonicalize_tie_dispatch=True,
                regional_transfer={"initial_fraction": initial,
                                   "maximum_fraction": 1.0,
                                   "line_capacity_mw": LINE_CAPACITY_MW,
                                   "max_lines": max_lines,
                                   "existing_capacity_mw": existing_cap,
                                   "existing_station_pair": LINE_PAIR,
                                   "new_line_station_pair": LINE_PAIR},
            )
            y = years[0]
            for kind, cap_mw in (("existing", existing_cap),
                                 ("new", LINE_CAPACITY_MW * y["line_built"])):
                for scenario in ("forward", "reverse"):
                    outgoing = [t for t in transfers if t["scenario"] == scenario
                                and t["tie_id"] == f"REGIONAL-{kind}"
                                and t["receiver_station_id"] == "REGIONAL-HUB"]
                    if sum(float(t["transfer_mw"]) for t in outgoing) > cap_mw + 1e-5:
                        raise AssertionError(f"{name} {scenario} {kind} 超过功率上限")
                    if any(float(t["transfer_mw"]) > 1e-5
                           and t["donor_station_id"] not in LINE_PAIR for t in outgoing):
                        raise AssertionError(f"{name} {scenario} {kind} 超出候选站点")
            new_transfer = sum(float(t["transfer_mw"]) for t in transfers
                               if t["year"] == 2025 and t["scenario"] == "forward"
                               and t["tie_id"] == "REGIONAL-new"
                               and t["receiver_station_id"] == "REGIONAL-HUB")
            existing_transfer = sum(float(t["transfer_mw"]) for t in transfers
                                    if t["year"] == 2025 and t["scenario"] == "forward"
                                    and t["tie_id"] == "REGIONAL-existing"
                                    and t["receiver_station_id"] == "REGIONAL-HUB")
            row = {"case_id": name, "year": 2025, "initial_transfer_fraction_proxy": initial,
                   "existing_transfer_cap_mw": existing_cap,
                   "maximum_new_lines": max_lines,
                   "line_station_pair": "BDZ-00027--BDZ-00048",
                   "new_lines_selected": y["line_built"],
                   "new_line_forward_transfer_mw": round(new_transfer, 6),
                   "existing_forward_transfer_mw": round(existing_transfer, 6),
                   "new_line_capex_10k_cny": y["new_line_capex_10k_cny"],
                   "transformer_capex_10k_cny": round(sum(float(s["transformer_capex_10k_cny"]) for s in station), 6),
                   "new_storage_modules": sum(int(s["new_storage_modules"]) for s in station),
                   "selected_capacity_mva": y["selected_capacity_mva"],
                   "synchronous_forward_peak_mw": y["synchronous_forward_peak_mw"],
                   "clr": y["actual_clr"],
                   "lifecycle_npv_10k_cny": summary["objective_npv_10k_cny"],
                   "solver_status": summary["solver_status"]}
            rows.append(row)
            write_csv(station, output_dir / f"{name}_stations.csv")
            if transfers:
                write_csv(transfers, output_dir / f"{name}_transfers.csv")
            else:
                (output_dir / f"{name}_transfers.csv").unlink(missing_ok=True)
            print(name, row, flush=True)
        write_csv(rows, output_dir / "comparison.csv")
        by_id = {r["case_id"]: r for r in rows}
        for prefix in ("zero_existing", "t01_section", "sample_proxy"):
            if (by_id[f"{prefix}_one_line"]["lifecycle_npv_10k_cny"]
                    > by_id[f"{prefix}_no_line"]["lifecycle_npv_10k_cny"] + 1e-3):
                raise AssertionError("允许新线后最优目标值不得变差")
        sensitivity = []
        base_ratios = base_cost_ratios(LINE_UNIT_COST, LINE_EXTRA_COST, LINE_CAPACITY_MW, LINE_KM)
        for unit_cost in (44.543, 60.0, 90.0, 100.0):
            _, years, _, summary = optimizer.solve_layer(
                PIZHOU, baseline, scenes, durations, peaks, catalog, coefficients,
                optimizer.cost_factors(), 2.0, True,
                line_km=LINE_KM, line_unit_cost=unit_cost,
                line_extra_capex_10k_cny=LINE_EXTRA_COST,
                policy_peak_basis="annual", max_storage_modules=50,
                allow_capacity_release=False, preserve_baseline_forward_margin=True,
                prefer_reserve_at_equal_cost=True, canonicalize_tie_dispatch=True,
                regional_transfer={"initial_fraction": sample["initial_fraction"],
                                   "maximum_fraction": 1.0,
                                   "line_capacity_mw": LINE_CAPACITY_MW,
                                   "max_lines": 1,
                                   "existing_capacity_mw": sample["sample_transfer_screen_mw"],
                                   "existing_station_pair": LINE_PAIR,
                                   "new_line_station_pair": LINE_PAIR},
            )
            sensitivity.append({"line_unit_cost_10k_per_km": unit_cost,
                                "line_extra_capex_10k_cny": LINE_EXTRA_COST,
                                "candidate_capex_10k_cny": LINE_KM * unit_cost + LINE_EXTRA_COST,
                                "transformer_to_line_base_ratio": round(
                                    base_ratios["transformer_expansion_10k_per_effective_mw"] /
                                    ((LINE_KM * unit_cost + LINE_EXTRA_COST) / LINE_CAPACITY_MW), 6),
                                "expansion_to_storage_base_ratio": round(base_ratios["expansion_to_storage_base_ratio"], 6),
                                "new_lines_selected": years[0]["line_built"],
                                "lifecycle_npv_10k_cny": summary["objective_npv_10k_cny"],
                                "reference_status": "scenario_price_not_Xuzhou_quote"})
        write_csv(sensitivity, output_dir / "line_price_sensitivity.csv")
        storage_sensitivity = []
        for storage_scale in (1.0, .7, .5, .3, .2):
            station, years, _, summary = optimizer.solve_layer(
                PIZHOU, baseline, scenes, durations, peaks, catalog, coefficients,
                optimizer.cost_factors(), 2.0, True,
                line_km=LINE_KM, line_unit_cost=LINE_UNIT_COST,
                line_extra_capex_10k_cny=LINE_EXTRA_COST,
                storage_cost_scale=storage_scale,
                policy_peak_basis="annual", max_storage_modules=50,
                allow_capacity_release=False, preserve_baseline_forward_margin=True,
                prefer_reserve_at_equal_cost=True, canonicalize_tie_dispatch=True,
                regional_transfer={"initial_fraction": sample["initial_fraction"],
                                   "maximum_fraction": 1.0,
                                   "line_capacity_mw": LINE_CAPACITY_MW,
                                   "max_lines": 1,
                                   "existing_capacity_mw": sample["sample_transfer_screen_mw"],
                                   "existing_station_pair": LINE_PAIR,
                                   "new_line_station_pair": LINE_PAIR},
            )
            storage_sensitivity.append({
                "storage_price_scale": storage_scale,
                "transformer_to_line_base_ratio": round(base_ratios["transformer_to_line_base_ratio"], 6),
                "expansion_to_storage_base_ratio": round(
                    base_ratios["expansion_to_storage_base_ratio"] / storage_scale, 6),
                "new_lines_selected": years[0]["line_built"],
                "storage_modules_selected": sum(int(s["new_storage_modules"]) for s in station),
                "lifecycle_npv_10k_cny": summary["objective_npv_10k_cny"],
                "reference_status": "storage_price_sensitivity_not_market_quote"})
        write_csv(storage_sensitivity, output_dir / "storage_price_sensitivity.csv")
        (output_dir / "assumptions.json").write_text(json.dumps({
            "scope": "static_2025_counterfactual_with_2021_initial_state_not_multiyear_recommendation",
            "line_cost_reference": "https://www.huarong.gov.cn/33157/64140/64170/content_1874487.html",
            "line_cost_reference_year_location": "2020_Hunan_Huarong_not_Xuzhou_quote",
            "overhead_10k_per_km": OVERHEAD_10K_PER_KM,
            "cable_electrical_only_10k_per_km": CABLE_10K_PER_KM,
            "overhead_fraction_assumption": OVERHEAD_SHARE,
            "line_km_assumption": LINE_KM,
            "switch_10k_each": SWITCH_10K_EACH,
            "switch_count_assumption": SWITCH_COUNT,
            "line_capex_10k_cny": LINE_KM * LINE_UNIT_COST + LINE_EXTRA_COST,
            "line_capacity_mw": LINE_CAPACITY_MW,
            "line_capacity_source": "2025_Dunzhen_23_24_isolatable_load_7.491MW_upper_before_receiver_check",
            "candidate_pair": LINE_PAIR,
            "existing_transfer_fraction_source": sample,
            "t01_isolatable_section_mw": t01_section_mw,
            "maximum_fraction": "1.0_nonbinding_fraction_ceiling_new_line_limited_by_mw_and_candidate_pair",
            "missing_costs": "cable_civil_land_station_outgoing_bay_protection_may_raise_cost",
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return rows
    finally:
        optimizer.YEARS = original_years


if __name__ == "__main__":
    run()
