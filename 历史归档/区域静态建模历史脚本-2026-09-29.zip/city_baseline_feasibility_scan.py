"""留档：市区 2021 候选起点与 2022—2025 刚性路径的可行性。"""

from pathlib import Path

from .city_mapping_audit import write_csv
from .regional_static_milp_v2 import input_data, optimize


OUTPUT = Path(__file__).resolve().parent / "outputs/city_2021_baseline_feasibility_scan.csv"
CAPS = (2864, 2840, 2839, 2835, 2830, 2825, 2824, 2823, 2822, 2821, 2820)


def run(output=OUTPUT):
    rows = []
    region = ("QX-00007", 110)
    for cap in CAPS:
        baseline, _, _, peaks, _, _ = input_data("observed_annual", region, cap)
        selected = sum(float(r["simulation_capacity_mva_2021"]) for r in baseline.values())
        status, npv = "infeasible", ""
        try:
            summary, _, _, _, _, _ = optimize(
                "rigid", region=region, city_baseline_cap_mva=cap,
                require_transformer_n1=True, n1_load_requirement="bc_min_service_static",
                max_new_lines=30)
            status, npv = "feasible", summary["objective_npv_10k"]
        except ValueError as exc:
            if "infeasible" not in str(exc).lower():
                raise
        rows.append({"input_baseline_upper_mva": cap,
                     "selected_baseline_mva": selected,
                     "2021_district_load_source_mw": peaks[region + (2021,)],
                     "2021_clr": selected / peaks[region + (2021,)],
                     "rigid_path_status": status,
                     "feasible_lifecycle_npv_10k": npv,
                     "note": "candidate_allocation_changes_with_cap;_not_global_maximum_proof"})
        print(cap, selected, status, flush=True)
    write_csv(rows, output)
    return rows


if __name__ == "__main__":
    run()
