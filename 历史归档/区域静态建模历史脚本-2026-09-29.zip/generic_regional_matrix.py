"""单位100 MW两站标准区域的参数外推矩阵，指标按修订稿定义计算。"""

import json
from itertools import product
from pathlib import Path

from .annual_no_tie_investment_submodel import YEARS
from .city_mapping_audit import write_csv
from .incremental_cost import replacement_cost_coefficients
from .joint_lifecycle_optimizer import cost_factors, solve_layer
from .regional_revision_run import OUTPUT, LINE_CAPACITY_MW, LINE_KM, base_cost_ratios


DEST = OUTPUT / "generic_matrix"
LAYER = ("GENERIC-100MW", 110)
LOAD_SHARES = {"G-A": .4, "G-B": .6}
BASE_USER_MAX_MW = 100.0
ANNUAL_LOAD_FACTOR = .55
PV_EQUIVALENT_HOURS = 1200.0
MIDDAY_LOAD_FRACTION = .3
PV_MIDDAY_OUTPUT_FRACTION = .8
YEARS_ALL = (2021, *YEARS)


def make_inputs(source_load_ratio: float, peak_growth: float, pv_share_a: float):
    baseline, scenes, durations, peaks = {}, {}, {}, {}
    pv_shares = {"G-A": pv_share_a, "G-B": 1 - pv_share_a}
    for year in YEARS_ALL:
        user_max = BASE_USER_MAX_MW * (1 + peak_growth) ** (year - 2021)
        peaks[LAYER + (year,)] = user_max
        if year == 2021:
            continue
        dg_installed = source_load_ratio * user_max
        for site, load_share in LOAD_SHARES.items():
            key = LAYER + (site,)
            forward = user_max * load_share
            midday_pv = PV_MIDDAY_OUTPUT_FRACTION * dg_installed * pv_shares[site]
            midday_user = MIDDAY_LOAD_FRACTION * forward
            scenes[key, year] = {
                "estimated_station_forward_peak_mw": forward,
                "reverse_screen_mw": max(0.0, midday_pv - midday_user),
            }
    for site, load_share in LOAD_SHARES.items():
        key = LAYER + (site,)
        baseline[key] = {"simulation_unit_1_mva": 40.0,
                         "simulation_unit_2_mva": 40.0,
                         "estimated_forward_peak_mw_2021": BASE_USER_MAX_MW * load_share}
        durations[key] = {"forward_d95_max_run_hours": 3,
                          "reverse_d95_max_run_hours": 3}
    return baseline, scenes, durations, peaks


def run(output_dir: Path = DEST) -> list[dict]:
    output_dir = Path(output_dir)
    ratios = base_cost_ratios()
    coefficients = {110: next(r["base_coefficient_10k_cny_per_purchased_mva"]
                              for r in replacement_cost_coefficients() if r["voltage_kv"] == 110)}
    catalog = {LAYER: [20.0, 31.5, 40.0, 50.0, 63.0, 80.0, 100.0]}
    rows, annual = [], []
    combinations = product((.5, 1.25, 2.0), (-.02, .03, .08),
                           (0.0, .15, .30), (.65, .80))
    for index, (source_load, growth, existing_fraction, pv_share_a) in enumerate(combinations, start=1):
        case_id = f"G{index:02d}"
        baseline, scenes, durations, peaks = make_inputs(source_load, growth, pv_share_a)
        stations, years, transfers, summary = solve_layer(
            LAYER, baseline, scenes, durations, peaks, catalog, coefficients,
            cost_factors(), 2.0, True, line_km=LINE_KM,
            policy_peak_basis="annual", max_storage_modules=50,
            allow_capacity_release=True, prefer_reserve_at_equal_cost=True,
            canonicalize_tie_dispatch=True, contingency_service_fraction=None,
            minimum_clr_by_year={year: 1.5 for year in YEARS},
            regional_transfer={"initial_fraction": existing_fraction,
                               "maximum_fraction": min(existing_fraction + .4, .8),
                               "line_capacity_mw": LINE_CAPACITY_MW,
                               "max_lines": 12},
        )
        for year in years:
            selected_stations = [station for station in stations if station["year"] == year["year"]]
            annual.append({"case_id": case_id, "year": year["year"],
                           "capacity_mva": year["selected_capacity_mva"],
                           "clr": year["actual_clr"],
                           "transformer_capex_10k_cny": round(sum(float(station["transformer_capex_10k_cny"])
                                                                      for station in selected_stations), 6),
                           "released_capacity_mva": round(sum(float(station["released_capacity_mva"])
                                                              for station in selected_stations), 6),
                           "storage_modules": year["storage_modules_in_service"],
                           "new_lines": year["line_built"],
                           "annual_npv_10k_cny": year["year_lifecycle_npv_10k_cny"]})
        final = years[-1]
        user_max = peaks[LAYER + (2025,)]
        dg_installed = source_load * user_max
        annual_generation = dg_installed * PV_EQUIVALENT_HOURS
        annual_user_energy = user_max * ANNUAL_LOAD_FACTOR * 8760
        midday_net = MIDDAY_LOAD_FRACTION * user_max - PV_MIDDAY_OUTPUT_FRACTION * dg_installed
        reverse_transfer_existing = sum(float(r["transfer_mw"]) for r in transfers
                                        if r["year"] == 2025 and r["scenario"] == "reverse"
                                        and r["tie_id"] == "REGIONAL-existing"
                                        and r["receiver_station_id"] == "REGIONAL-HUB")
        reverse_transfer_new = sum(float(r["transfer_mw"]) for r in transfers
                                   if r["year"] == 2025 and r["scenario"] == "reverse"
                                   and r["tie_id"] == "REGIONAL-new"
                                   and r["receiver_station_id"] == "REGIONAL-HUB")
        rows.append({"case_id": case_id, "year": 2025,
                     "region_basis": "synthetic_100MW_2021_two_station_region",
                     "source_load_ratio_dg_installed_over_user_max": source_load,
                     "dg_energy_penetration_generation_over_user_energy": round(annual_generation / annual_user_energy, 9),
                     "annual_max_net_load_average_growth": growth,
                     "max_positive_net_load_mw": round(user_max, 6),
                     "max_absolute_net_load_mw": round(max(user_max, abs(midday_net)), 6),
                     "existing_transfer_fraction": existing_fraction,
                     "pv_installation_share_station_a": pv_share_a,
                     "transformer_line_lifecycle_cost_ratio": ratios["transformer_to_line_lifecycle_ratio"],
                     "expansion_storage_lifecycle_cost_ratio": ratios["expansion_to_storage_lifecycle_ratio"],
                     "recommended_capacity_mva": final["selected_capacity_mva"],
                     "recommended_clr": final["actual_clr"],
                     "path_transformer_capex_10k_cny": round(sum(float(station["transformer_capex_10k_cny"])
                                                                      for station in stations), 6),
                     "path_released_capacity_mva": round(sum(float(station["released_capacity_mva"])
                                                               for station in stations), 6),
                     "storage_modules": final["storage_modules_in_service"],
                     "new_10kv_lines": final["line_built"],
                     "existing_reverse_transfer_mw": round(reverse_transfer_existing, 6),
                     "new_line_reverse_transfer_mw": round(reverse_transfer_new, 6),
                     "path_npv_10k_cny": summary["objective_npv_10k_cny"],
                     "solver_status": summary["solver_status"]})
        write_csv(rows, output_dir / "generic_recommendation_matrix.csv")
        write_csv(annual, output_dir / "generic_annual_paths.csv")
        print(f"DONE {case_id} {source_load} {growth} {existing_fraction} {pv_share_a}", flush=True)
    (output_dir / "assumptions.json").write_text(
        json.dumps({"status": "generic_synthetic_extrapolation_not_measured_region",
                    "2021_user_max_mw": BASE_USER_MAX_MW,
                    "2021_transformer_capacity_mva": 160,
                    "recommended_clr_interval": [1.5, 2.0],
                    "station_user_load_shares": LOAD_SHARES,
                    "source_load_ratio_levels": [.5, 1.25, 2.0],
                    "annual_max_net_load_growth_levels": [-.02, .03, .08],
                    "initial_transfer_fraction_levels": [0, .15, .30],
                    "station_a_pv_share_levels": [.65, .8],
                    "annual_user_load_factor": ANNUAL_LOAD_FACTOR,
                    "pv_equivalent_generation_hours": PV_EQUIVALENT_HOURS,
                    "midday_load_fraction_of_night_peak": MIDDAY_LOAD_FRACTION,
                    "midday_pv_output_fraction": PV_MIDDAY_OUTPUT_FRACTION,
                    "derived_cost_ratios": ratios,
                    "row_count": len(rows)}, ensure_ascii=False, indent=2) + "\n",
                   encoding="utf-8")
    return rows


if __name__ == "__main__":
    run()
