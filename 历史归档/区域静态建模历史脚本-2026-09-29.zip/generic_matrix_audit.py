"""核对通用矩阵指标定义、场景覆盖与年度费用，并输出导则中文名称表。"""

import json
from collections import Counter
from pathlib import Path

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .generic_regional_matrix import DEST, ANNUAL_LOAD_FACTOR, PV_EQUIVALENT_HOURS


DISPLAY = {
    "case_id": "场景编号",
    "year": "规划年",
    "source_load_ratio_dg_installed_over_user_max": "分布式电源装机渗透率（源荷比）",
    "dg_energy_penetration_generation_over_user_energy": "分布式电源电量渗透率",
    "annual_max_net_load_average_growth": "年最大净负荷平均增长率",
    "max_positive_net_load_mw": "最大正向净负荷（MW）",
    "max_absolute_net_load_mw": "净负荷绝对峰值（MW，模型压力筛查）",
    "existing_transfer_fraction": "现有可转移比例（模型输入）",
    "pv_installation_share_station_a": "甲站装机占比（模型输入）",
    "transformer_line_lifecycle_cost_ratio": "主变与线路成本比（模型输入）",
    "expansion_storage_lifecycle_cost_ratio": "增容与配储成本比（模型输入）",
    "recommended_capacity_mva": "推荐在役主变容量（MVA）",
    "recommended_clr": "容载比",
    "path_transformer_capex_10k_cny": "规划期主变扩容投资（万元）",
    "path_released_capacity_mva": "规划期存量容量退出（MVA）",
    "storage_modules": "在役储能柜数",
    "new_10kv_lines": "新建10千伏联络线路数",
    "existing_reverse_transfer_mw": "现有联络反向转移（MW）",
    "new_line_reverse_transfer_mw": "新线反向转移（MW）",
    "path_npv_10k_cny": "全寿命增量费用现值（万元）",
    "solver_status": "求解状态",
}


def audit(directory: Path = DEST) -> dict:
    directory = Path(directory)
    rows = read_csv(directory / "generic_recommendation_matrix.csv")
    annual = read_csv(directory / "generic_annual_paths.csv")
    assert len(rows) == 54 and len(annual) == 216
    assert len({r["case_id"] for r in rows}) == 54
    assert all(r["solver_status"] == "proven_optimal_under_stated_static_proxy" for r in rows)
    expected = {(a, b, c, d) for a in (.5, 1.25, 2.0)
                for b in (-.02, .03, .08) for c in (0.0, .15, .3)
                for d in (.65, .8)}
    actual = {(float(r["source_load_ratio_dg_installed_over_user_max"]),
               float(r["annual_max_net_load_average_growth"]),
               float(r["existing_transfer_fraction"]),
               float(r["pv_installation_share_station_a"])) for r in rows}
    assert actual == expected
    for row in rows:
        ratio = float(row["source_load_ratio_dg_installed_over_user_max"])
        penetration = ratio * PV_EQUIVALENT_HOURS / (ANNUAL_LOAD_FACTOR * 8760)
        assert abs(float(row["dg_energy_penetration_generation_over_user_energy"]) - penetration) < 1e-8
        case_annual = sorted((r for r in annual if r["case_id"] == row["case_id"]),
                             key=lambda r: int(r["year"]))
        assert [int(r["year"]) for r in case_annual] == [2022, 2023, 2024, 2025]
        assert abs(float(case_annual[-1]["clr"]) - float(row["recommended_clr"])) < 1e-8
        assert abs(float(case_annual[-1]["capacity_mva"]) - float(row["recommended_capacity_mva"])) < 1e-8
        assert abs(sum(float(r["annual_npv_10k_cny"]) for r in case_annual) -
                   float(row["path_npv_10k_cny"])) < 1e-3
        assert abs(sum(float(r["transformer_capex_10k_cny"]) for r in case_annual) -
                   float(row["path_transformer_capex_10k_cny"])) < 1e-4
        assert abs(float(row["recommended_capacity_mva"]) /
                   float(row["max_positive_net_load_mw"]) - float(row["recommended_clr"])) < 1e-8
        assert 1.5 - 1e-8 <= float(row["recommended_clr"]) <= 2.0 + 1e-8
    display_rows = [{translated: row[source] for source, translated in DISPLAY.items()}
                    for row in rows]
    write_csv(display_rows, directory / "通用推荐矩阵_导则指标名称.csv")
    measures = Counter("new_line" if int(r["new_10kv_lines"]) else
                       "storage" if int(r["storage_modules"]) else
                       "neither_new_line_nor_storage" for r in rows)
    result = {"status": "PASS", "scenarios": len(rows), "annual_rows": len(annual),
              "recommended_clr_min": min(float(r["recommended_clr"]) for r in rows),
              "recommended_clr_max": max(float(r["recommended_clr"]) for r in rows),
              "measure_counts": dict(measures),
              "scope": "synthetic_two_station_100MW_region_not_geographic_regulation"}
    (directory / "audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                                           encoding="utf-8")
    return result


if __name__ == "__main__":
    print(audit())
