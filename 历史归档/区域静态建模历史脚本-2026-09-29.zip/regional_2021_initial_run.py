"""按共同2021仿真初始状态重求区域刚性措施路径；原首轮输出保留为诊断。"""

from pathlib import Path

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .pv_source_audit import read_monthly_pv
from .regional_revision_run import pizhou_sample_fraction, run


OUTPUT = OUTPUT_DIR / "capacity_release_simulation/regional_2021_initial_2026_09_28"


def build_initial_state(cases: tuple[str, ...]) -> list[dict]:
    initial_fraction = pizhou_sample_fraction()["initial_fraction"]
    baseline = read_csv(OUTPUT_DIR / "planning_2021_common_baseline_stations.csv")
    reverse = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
               for r in read_csv(OUTPUT_DIR / "annual_reverse_station_proxy_2021_2025.csv")
               if int(r["year"]) == 2021 and r["variant"] == "night_central"}
    included = {"QX-00005" if case.startswith("pizhou") else "QX-00007" for case in cases}
    return [{
        "study_region_id": r["study_region_id"], "voltage_kv": r["voltage_kv"],
        "model_station_id": r["model_station_id"], "year": 2021,
        "simulation_unit_1_mva": r["simulation_unit_1_mva"],
        "simulation_unit_2_mva": r["simulation_unit_2_mva"],
        "simulation_capacity_mva": r["simulation_capacity_mva_2021"],
        "estimated_forward_peak_mw": r["estimated_forward_peak_mw_2021"],
        "estimated_reverse_screen_mw": reverse[(r["study_region_id"], 110,
                                                 r["model_station_id"])]["reverse_at_template_proxy_mw"],
        "storage_modules": 0,
        "regional_existing_transfer_fraction_scenario":
            initial_fraction if r["study_region_id"] == "QX-00005" else .50,
        "capacity_source": "planning_2021_common_baseline_stations;_counterfactual_not_asset_record",
        "forward_peak_source": r["scenario_scale_basis"],
        "pv_2021_source": "2023_monthly_capacity_backcast_scenario_no_2021_observation",
        "transfer_source": ("2025_six_feeder_sample_extrapolated_back_to_2021"
                            if r["study_region_id"] == "QX-00005" else "meeting_50pct_assumption"),
    } for r in baseline if r["study_region_id"] in included and int(r["voltage_kv"]) == 110]


def build_initial_region_state(cases: tuple[str, ...]) -> list[dict]:
    included = {"QX-00005" if case.startswith("pizhou") else "QX-00007" for case in cases}
    official = {(r["region_id"], int(r["voltage_kv"]), int(r["year"])): r
                for r in read_csv(OUTPUT_DIR / "official_annual.csv")}
    planning = {(r["study_region_id"], int(r["voltage_kv"]), int(r["year"])): r
                for r in read_csv(OUTPUT_DIR / "planning_2021_common_baseline_layers.csv")}
    monthly, _ = read_monthly_pv()
    pv = {(r["region_id"], int(r["year"]), int(r["month"])): float(r["source_value"])
          for r in monthly}
    sample = pizhou_sample_fraction()["initial_fraction"]
    rows = []
    for region in sorted(included):
        asset = official[region, 110, 2021]
        state = planning[region, 110, 2021]
        capacity = float(state["capacity_mva"])
        region_peak = float(state["net_forward_peak_mw"])
        pv_2023 = pv[region, 2023, 12]
        pv_2024 = pv[region, 2024, 12]
        # 原表“万千瓦”按项目已确认口径换成MW；数值仍是2021年回推估计。
        estimated_pv_mw = 10 * pv_2023 * (pv_2023 / pv_2024) ** 2
        rows.append({
            "study_region_id": region, "voltage_kv": 110, "year": 2021,
            "reported_region_capacity_mva": asset["capacity_mva"],
            "simulation_capacity_mva": capacity,
            "simulation_minus_reported_mva": (round(capacity - float(asset["capacity_mva"]), 6)
                                              if region == "QX-00005" else ""),
            "capacity_comparison_scope": ("pizhou_region_same_boundary"
                                          if region == "QX-00005" else "city_29_station_sample_vs_full_region_not_comparable"),
            "reported_downward_load_mw": asset["reported_downward_load_mw"],
            "simulation_forward_peak_mw": region_peak,
            "simulation_clr": round(capacity / region_peak, 9),
            "estimated_december_pv_connected_mw": round(estimated_pv_mw, 6),
            "pv_estimation_method": "2023_Dec_value_times_(2023_Dec_over_2024_Dec)^2;_unit_10MW",
            "initial_storage_modules_scenario": 0,
            "initial_existing_transfer_fraction_scenario": sample if region == "QX-00005" else .50,
            "initial_transfer_source": ("2025_six_feeder_sample_extrapolated_back_to_2021"
                                        if region == "QX-00005" else "meeting_50pct_assumption"),
            "capacity_source": "planning_2021_common_baseline_layers.csv",
            "reported_source": ("近5年容载比.xlsx_Sheet1_row19" if region == "QX-00005"
                                else "近5年容载比.xlsx_Sheet1_row9"),
            "pv_source": "逐月分县分布式光伏.xlsx_2023_and_2024_Dec",
        })
    return rows


def main(output_dir: Path = OUTPUT, cases: tuple[str, ...] = ("pizhou_base", "city_base"),
         **model_kwargs):
    output_dir = Path(output_dir)
    write_csv(build_initial_state(cases), output_dir / "initial_state_2021.csv")
    write_csv(build_initial_region_state(cases), output_dir / "initial_region_state_2021.csv")
    return run(output_dir=output_dir, cases=cases,
               baseline_mode="planning_2021",
               allow_capacity_release=False,
               preserve_baseline_forward_margin=True,
               **model_kwargs)


if __name__ == "__main__":
    main()
