"""对非导则强制项的2021正向裕度保留比例作逐年路径诊断。"""

import json
from pathlib import Path

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .joint_lifecycle_optimizer import load_inputs
from .regional_2021_initial_run import main
from .regional_revision_audit import audit
from .regional_revision_run import pizhou_sample_fraction
from .tie_section_audit import transferable_section


OUTPUT = OUTPUT_DIR / "capacity_release_simulation/regional_2021_initial_2026_09_28/pizhou_t01_margin_scan"


def run(output_dir: Path = OUTPUT) -> list[dict]:
    output_dir = Path(output_dir)
    sample = pizhou_sample_fraction()
    t01 = transferable_section()["2025_feeder_stress_section_p_seed_mw"]
    _, scene, _, _, _, _ = load_inputs()
    station = ("QX-00005", 110, "BDZ-00027")
    base = float(scene[station, 2025]["estimated_station_forward_peak_mw"])
    growth = {year: float(scene[station, year]["estimated_station_forward_peak_mw"]) / base
              for year in (2022, 2023, 2024, 2025)}
    rows = []
    for fraction in (0.0, .25, .5, .75, 1.0):
        case_dir = output_dir / f"margin_{fraction:.2f}"
        try:
            summary = main(
                output_dir=case_dir, cases=("pizhou_base",),
                baseline_margin_fraction=fraction,
                line_unit_cost=33.6, line_extra_capex=6.0,
                line_capacity_mw=7.491,
                line_capacity_mw_by_year={y: 7.491 * growth[y] for y in growth},
                max_lines=1,
                new_line_station_pair=("BDZ-00027", "BDZ-00048"),
                existing_station_pair=("BDZ-00027", "BDZ-00048"),
                existing_transfer_capacity_mw=t01,
                existing_transfer_capacity_mw_by_year={y: t01 * growth[y] for y in growth},
                maximum_transfer_fraction=1.0,
                prefer_reserve_at_equal_cost=False,
                canonicalize_tie_dispatch=True,
            )[0]
            audit_result = audit(case_dir)
            years = read_csv(case_dir / "annual_measures.csv")
            row = {"baseline_margin_fraction": fraction, "status": audit_result["status"],
                   "objective_npv_10k_cny": summary["objective_npv_10k_cny"],
                   "2025_capacity_mva": next(r["selected_capacity_mva"] for r in years if int(r["year"]) == 2025),
                   "2025_clr": next(r["clr"] for r in years if int(r["year"]) == 2025),
                   "2025_storage_modules": next(r["storage_modules_in_service"] for r in years if int(r["year"]) == 2025),
                   "2025_new_lines": next(r["new_lines_in_service"] for r in years if int(r["year"]) == 2025),
                   "reason": ""}
        except ValueError as exc:
            if "infeasible" not in str(exc).lower():
                raise
            row = {"baseline_margin_fraction": fraction, "status": "INFEASIBLE",
                   "objective_npv_10k_cny": "", "2025_capacity_mva": "",
                   "2025_clr": "", "2025_storage_modules": "",
                   "2025_new_lines": "", "reason": str(exc)}
        rows.append(row)
        print(row, flush=True)
    write_csv(rows, output_dir / "summary.csv")
    (output_dir / "assumptions.json").write_text(json.dumps({
        "scope": "research_sensitivity_not_guide_mandated_margin",
        "existing_transfer": "T01_2025_isolatable_section_backcast_by_donor_station_peak",
        "new_line": "Dunzhen_2025_candidate_backcast_by_donor_station_peak",
        "line_cost": "2020_Hunan_public_low_cost_3km_two_switches",
        "2021_baseline": "planning_2021_common_baseline_stations.csv",
        "capacity_release_after_2021": False,
        "annual_rigid_clr_cap": 2.0,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return rows


if __name__ == "__main__":
    run()
