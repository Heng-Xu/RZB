"""邳州 2021 近 2.0 起点下的刚性联络与弹性扩容研究情景。"""

import json
from collections import defaultdict
from pathlib import Path

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .regional_revision_audit import audit
from .regional_revision_run import run
from .tie_section_audit import transferable_section
from .planning_load_profile import weighted_annual_growth


OUTPUT = OUTPUT_DIR / "capacity_release_simulation/regional_rigid_elastic_research_2026_09_28"
BASELINE_SOURCE = OUTPUT_DIR / "baseline_2021_station_candidates.csv"
REVERSE_SOURCE = OUTPUT_DIR / "annual_reverse_station_proxy_2021_2025.csv"
RELAXED_HUB = OUTPUT / "hub_relaxation"


def screen_station_pairs(annual_load: dict[int, float], output_dir: Path) -> list[tuple[str, str]]:
    """由区域池松弛解的站点净转移量产生站对候选；最终仍由站对模型重优化。"""
    selected = set()
    trace = []
    for case in ("pizhou_rigid", "pizhou_elastic"):
        rows = read_csv(RELAXED_HUB / f"{case}_transfers.csv")
        for year in (2022, 2023, 2024, 2025):
            net = defaultdict(float)
            for row in rows:
                if int(row["year"]) != year or row["scenario"] != "forward" or row["tie_id"] != "REGIONAL-new":
                    continue
                power = float(row["transfer_mw"])
                if row["receiver_station_id"] == "REGIONAL-HUB":
                    net[row["donor_station_id"]] += power
                else:
                    net[row["receiver_station_id"]] -= power
            donors = {station: power for station, power in net.items() if power > 1e-6}
            receivers = {station: -power for station, power in net.items() if power < -1e-6}
            limit = 7.491 * annual_load[year] / annual_load[2025]
            used = defaultdict(float)
            while donors and receivers:
                choices = []
                for donor, available in donors.items():
                    for receiver, needed in receivers.items():
                        pair = tuple(sorted((donor, receiver)))
                        room = limit - used[pair]
                        if room > 1e-6:
                            choices.append((int(pair in selected), min(available, needed, room), pair,
                                            donor, receiver))
                if not choices:
                    break
                _, power, pair, donor, receiver = max(choices)
                used[pair] += power
                selected.add(pair)
                donors[donor] -= power
                receivers[receiver] -= power
                if donors[donor] < 1e-6:
                    del donors[donor]
                if receivers[receiver] < 1e-6:
                    del receivers[receiver]
            trace.append({"case": case, "year": year, "candidate_pairs_used": len(used),
                          "unallocated_relaxed_mw": round(sum(donors.values()), 6),
                          "screening_rule": "greedy_reuse_then_largest_feasible_OD_from_relaxed_net_flows"})
    pairs = sorted(selected)
    write_csv([{"from_station_id": a, "to_station_id": b,
                "route_status": "abstract_station_pair_candidate_not_surveyed"} for a, b in pairs],
              output_dir / "new_line_candidate_pairs.csv")
    write_csv(trace, output_dir / "candidate_pair_screen_trace.csv")
    return pairs


def observed_portfolio_pairs(output_dir: Path) -> list[tuple[str, str]]:
    """加权增长敏感性只在已选两方案的站对并集中重优化。"""
    pairs = set()
    for case in ("pizhou_rigid", "pizhou_elastic"):
        for row in read_csv(OUTPUT / f"{case}_transfers.csv"):
            if row["scenario"] == "infrastructure" and int(row["year"]) == 2025:
                pairs.add(tuple(sorted((row["donor_station_id"], row["receiver_station_id"]))))
    if not pairs:
        raise ValueError("原始逐年负荷方案尚未提供候选站对")
    result = sorted(pairs)
    write_csv([{"from_station_id": a, "to_station_id": b,
                "route_status": "observed_annual_portfolio_pair_for_weighted_growth_sensitivity"}
               for a, b in result], output_dir / "new_line_candidate_pairs.csv")
    return result


def write_initial_state(output_dir: Path) -> None:
    baseline = [r for r in read_csv(BASELINE_SOURCE)
                if r["study_region_id"] == "QX-00005" and int(r["voltage_kv"]) == 110]
    reverse = {r["model_station_id"]: r for r in read_csv(REVERSE_SOURCE)
               if r["study_region_id"] == "QX-00005" and int(r["voltage_kv"]) == 110
               and int(r["year"]) == 2021 and r["variant"] == "night_central"}
    initial = [{
        "study_region_id": r["study_region_id"], "voltage_kv": 110,
        "model_station_id": r["model_station_id"], "year": 2021,
        "simulation_unit_1_mva": r["simulation_unit_1_mva"],
        "simulation_unit_2_mva": r["simulation_unit_2_mva"],
        "simulation_capacity_mva": r["simulation_capacity_mva_2021"],
        "estimated_forward_peak_mw": r["estimated_forward_peak_mw_2021"],
        "estimated_reverse_screen_mw": reverse[r["model_station_id"]]["reverse_at_template_proxy_mw"],
        "capacity_source": "baseline_2021_station_candidates.csv;_near_2_counterfactual_not_asset_record",
        "forward_peak_source": r["scenario_scale_basis"],
        "station_allocation_rule": r["baseline_selection_rule"],
    } for r in baseline]
    assert len(initial) == 20
    assert abs(sum(float(r["simulation_capacity_mva"]) for r in initial) - 1463.5) < 1e-8
    write_csv(initial, output_dir / "initial_state_2021.csv")
    write_csv([{
        "region": "QX-00005", "year": 2021,
        "original_capacity_mva": 2027.0,
        "original_capacity_cell": "近5年容载比.xlsx::Sheet1!C19×10",
        "original_load_mw": 731.77,
        "original_load_cell": "近5年容载比.xlsx::Sheet1!D19×10",
        "capacity_at_exact_2_mva": 2 * 731.77,
        "discrete_planning_capacity_mva": 1463.5,
        "baseline_no_cost_release_mva": 2027 - 1463.5,
        "planning_clr": 1463.5 / 731.77,
        "status": "regional_source_cells_plus_counterfactual_station_allocation",
    }], output_dir / "initial_region_state_2021.csv")


def add_line_build_records_if_missing(output_dir: Path, cases: tuple[str, ...]) -> None:
    """兼容旧次运行文件；仅当全部建线站对均能由逐年转供唯一复原时补记。"""
    annual = read_csv(output_dir / "annual_measures.csv")
    for case in cases:
        path = output_dir / f"{case}_transfers.csv"
        if not path.exists():
            continue
        rows = read_csv(path)
        if any(r["scenario"] == "infrastructure" for r in rows):
            continue
        first_use = {}
        for row in rows:
            if row["tie_id"] != "REGIONAL-new" or float(row["transfer_mw"]) <= 1e-6:
                continue
            pair = tuple(sorted((row["donor_station_id"], row["receiver_station_id"])))
            first_use[pair] = min(first_use.get(pair, int(row["year"])), int(row["year"]))
        year_rows = sorted((r for r in annual if r["case_id"] == case), key=lambda r: int(r["year"]))
        if len(first_use) != int(year_rows[-1]["new_lines_in_service"]):
            raise ValueError("无法从转供记录唯一复原新建线路站对")
        for row in year_rows:
            year = int(row["year"])
            active = {pair for pair, first in first_use.items() if first <= year}
            built_count = int(row["new_lines_in_service"])
            if len(active) > built_count:
                raise ValueError("活跃站对数超出在役新线条数")
            future = sorted((pair for pair in first_use if pair not in active),
                            key=lambda pair: (first_use[pair], pair))
            if built_count - len(active) not in (0, len(future)):
                raise ValueError("投运年无法由转供记录唯一复原；须重新运行模型导出建线决策")
            # 全期建线站对恰等于全期出现转供的站对；提前投运者按首次使用年补足。
            built_pairs = active | set(future[:built_count - len(active)])
            if len(built_pairs) != built_count:
                raise ValueError("新建线路站对复原失败")
            for pair in sorted(built_pairs):
                rows.append({"study_region_id": "QX-00005", "voltage_kv": 110,
                             "year": year, "scenario": "infrastructure",
                             "tie_id": "REGIONAL-new-build",
                             "donor_feeder_id": pair[0], "receiver_feeder_id": pair[1],
                             "donor_station_id": pair[0], "receiver_station_id": pair[1],
                             "transfer_mw": 0.0,
                             "operation_basis": "uniquely_reconstructed_from_all_year_pair_flows_and_line_count",
                             "technical_scope": "abstract_station_pair_route_not_surveyed"})
        write_csv(rows, path)


def main(output_dir: Path = OUTPUT / "current_scopes", cases: tuple[str, ...] = ("pizhou_rigid", "pizhou_elastic"),
         load_scenario: str = "observed_annual",
         station_choice_slack_mva: float | None = None,
         elastic_no_10kv: bool = True):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_initial_state(output_dir)
    annual_load = {int(r["year"]): float(r["reported_downward_load_mw"])
                   for r in read_csv(OUTPUT_DIR / "official_annual.csv")
                   if r["region_id"] == "QX-00005" and int(r["voltage_kv"]) == 110}
    planning_load = dict(annual_load)
    if load_scenario == "weighted_4y_growth":
        growth, _ = weighted_annual_growth(annual_load)
        planning_load.update({year: annual_load[2021] * (1 + growth) ** (year - 2021)
                              for year in (2022, 2023, 2024, 2025)})
    annual_scale = {year: planning_load[year] / planning_load[2025]
                    for year in (2022, 2023, 2024, 2025)}
    needs_line_pairs = "pizhou_rigid" in cases or not elastic_no_10kv
    candidate_pairs = ((observed_portfolio_pairs(output_dir)
                        if load_scenario == "weighted_4y_growth"
                        else screen_station_pairs(annual_load, output_dir))
                       if needs_line_pairs else [])
    existing_section_mw = float(transferable_section()["2025_feeder_stress_section_p_seed_mw"])
    summaries = run(
        output_dir=output_dir, cases=cases,
        baseline_mode="near2_2021", allow_capacity_release=False,
        preserve_baseline_forward_margin=True, baseline_margin_fraction=1.0,
        line_unit_cost=33.6, line_extra_capex=6.0,
        line_capacity_mw=7.491, line_km=3.0, max_lines=30,
        line_capacity_mw_by_year={y: 7.491 * annual_scale[y] for y in annual_scale},
        existing_transfer_capacity_mw=existing_section_mw,
        existing_transfer_capacity_mw_by_year={y: existing_section_mw * annual_scale[y]
                                               for y in annual_scale},
        existing_station_pair=("BDZ-00027", "BDZ-00048"), new_line_station_pair=None,
        pairwise_transfer=True, new_line_candidate_pairs=candidate_pairs,
        pizhou_existing_fraction=0.0,
        load_scenario=load_scenario,
        maximum_transfer_fraction=1.0,
        elastic_clr_cap=2.4,
        minimum_clr_by_year={2022: 1.8, 2023: 1.8, 2024: 1.8, 2025: 1.8},
        station_choice_cap_slack_mva=station_choice_slack_mva,
        prefer_reserve_at_equal_cost=False,
        canonicalize_tie_dispatch=False,
        elastic_no_10kv=elastic_no_10kv,
    )
    add_line_build_records_if_missing(output_dir, cases)
    if elastic_no_10kv:
        for row in read_csv(output_dir / "annual_measures.csv"):
            if row["case_id"] != "pizhou_elastic":
                continue
            fields = ("existing_transfer_forward_mw", "existing_transfer_reverse_mw",
                      "new_line_transfer_forward_mw", "new_line_transfer_reverse_mw",
                      "new_lines_in_service", "new_lines_commissioned", "line_investment_10k_cny")
            if any(abs(float(row[field])) > 1e-8 for field in fields):
                raise AssertionError("弹性方案年度措施混入 10 kV 联络")
    result = audit(output_dir)
    (output_dir / "research_status.json").write_text(json.dumps({
        "audit": result, "baseline_discrete_capacity_mva": 1463.5,
        "baseline_release_mva": 563.5,
        "station_choice_screen": ("full_transformer_rating_catalog_without_capacity_cutoff"
                                  if station_choice_slack_mva is None else
                                  f"heuristic_capacity_cutoff_with_{station_choice_slack_mva}_MVA_slack"),
        "new_line_pair_screen": ("not_applicable_elastic_without_10kv" if not needs_line_pairs else
                                 f"{len(candidate_pairs)}_observed_annual_portfolio_pairs_only"
                                 if load_scenario == "weighted_4y_growth" else
                                 f"{len(candidate_pairs)}_pairs_from_hub_relaxation_net_flows;_not_exhaustive_full_network"),
        "transfer_scope": ("none_elastic_transformer_storage_only" if elastic_no_10kv and not needs_line_pairs else
                           "individual_station_pairs_with_one_new_line_per_pair;_physical_route_and_switch_not_yet_committed"),
        "existing_transfer_scope": ("none_elastic" if elastic_no_10kv and not needs_line_pairs else
                                    f"T01_section_{existing_section_mw:.8f}_MW_on_BDZ-00027_to_BDZ-00048,_annualized_by_county_load_ratio"),
        "new_line_scope": ("none_elastic" if elastic_no_10kv and not needs_line_pairs else
                           "7.491_MW_each,_3km_cost_estimate;_candidate_pair_chosen_by_model,_physical_route_not_verified"),
        "load_denominator_scope": "original_annual_downward_load_proxy_for_maximum_forward_net_load",
        "load_scenario": load_scenario,
        "elastic_scope": ("transformer_and_storage_only_no_existing_or_new_10kv;_research_cap_2.4;_guide_exception_requires_supply_safety_validation"
                          if elastic_no_10kv else
                          "research_cap_2.4;_guide_exception_requires_supply_safety_validation"),
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summaries


if __name__ == "__main__":
    main()
