"""按 DL/T 5729—2023 2.0.15 区分停运转供与正常场景负荷迁移。

这里只计算已列站对上的单跳可恢复量上界，不包含馈线故障分段、
潮流、电压或恢复时间，不能据此认定达到导则供电安全准则。
"""

import argparse
from collections import defaultdict
from pathlib import Path

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .regional_static_milp_v2 import (
    EXISTING_PAIR, LINE_MW_2025, OUTPUT, REGION,
    STORAGE_MWH_PER_MW, input_data,
)


def screen(directory: Path = OUTPUT, scheme: str = "rigid", load_scenario: str = "observed_annual"):
    directory = Path(directory)
    stations = read_csv(directory / f"{scheme}_stations.csv")
    line_file = directory / f"{scheme}_new_lines.csv"
    lines = read_csv(line_file) if line_file.exists() else []
    baseline, scenes, durations, peaks, _, _ = input_data(load_scenario)
    station_ids = sorted(key[2] for key in baseline)
    by_station = {(int(row["year"]), row["station"]): row for row in stations}
    existing_2025 = 4.49651196
    rows = []
    for year in (2022, 2023, 2024, 2025):
        scale = peaks[REGION + (year,)] / peaks[REGION + (2025,)]
        adjacencies = defaultdict(list)
        if scheme == "rigid":
            a, b = EXISTING_PAIR
            adjacencies[a].append((b, existing_2025 * scale, "existing"))
            adjacencies[b].append((a, existing_2025 * scale, "existing"))
            for line in lines:
                if int(line["commissioning_year"]) <= year:
                    a, b = line["station_a"], line["station_b"]
                    adjacencies[a].append((b, LINE_MW_2025 * scale, "new"))
                    adjacencies[b].append((a, LINE_MW_2025 * scale, "new"))
        for station_id in station_ids:
            station = REGION + (station_id,)
            demand = float(scenes[station, year]["estimated_station_forward_peak_mw"])
            upper = 0.0
            for recipient_id, line_limit, _ in adjacencies[station_id]:
                recipient = REGION + (recipient_id,)
                record = by_station[year, recipient_id]
                capacity = float(record["capacity_mva"])
                energy = float(record["storage_energy_mwh"])
                duration = int(durations[recipient]["forward_d95_max_run_hours"])
                recipient_load = float(scenes[recipient, year]["estimated_station_forward_peak_mw"])
                spare = max(0, .95 * capacity + energy / max(STORAGE_MWH_PER_MW, duration)
                            - recipient_load)
                upper += min(line_limit, spare)
            transferable = min(demand, upper)
            rows.append({"year": year, "scheme": scheme, "station": station_id,
                         "normal_station_load_proxy_mw": demand,
                         "single_hop_recovery_upper_mw": transferable,
                         "single_hop_recovery_upper_ratio": transferable / demand if demand > 0 else 1,
                         "incident_station_pair_count": len(adjacencies[station_id]),
                         "scope": "single_station_outage_one_hop_upper_only_not_N_minus_1_certification"})
    write_csv(rows, directory / f"{scheme}_outage_transfer_screen.csv")
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, default=OUTPUT)
    parser.add_argument("--scheme", choices=("rigid", "elastic"), default="rigid")
    parser.add_argument("--load-scenario", default="observed_annual")
    args = parser.parse_args()
    result = screen(args.directory, args.scheme, args.load_scenario)
    for year in (2022, 2023, 2024, 2025):
        local = [row for row in result if row["year"] == year]
        print(year, "connected", sum(row["incident_station_pair_count"] > 0 for row in local),
              "below30pct", sum(row["single_hop_recovery_upper_ratio"] < .3 for row in local))
