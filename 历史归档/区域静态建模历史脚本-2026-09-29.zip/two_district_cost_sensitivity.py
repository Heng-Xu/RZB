"""按实际价格建立两项成本比值，并分别改变线路及储能价格。"""

from pathlib import Path

from .city_mapping_audit import write_csv
from .regional_static_milp_v2 import LINE_CAPEX_10K, LINE_MW_2025, optimize


OUTPUT = Path(__file__).resolve().parent / "outputs/two_district_cost_sensitivity.csv"
REGIONS = (("QX-00005", 110, None), ("QX-00007", 110, 2823))


def run(output=OUTPUT):
    rows = []
    for region_id, kv, baseline_cap in REGIONS:
        for scheme in ("rigid", "elastic"):
            for component, scale in (("baseline", 1.0), ("line", .8),
                                     ("line", 1.2), ("storage", .8), ("storage", 1.2)):
                if scheme == "elastic" and component == "line":
                    continue
                kwargs = {"region": (region_id, kv), "require_transformer_n1": True,
                          "n1_load_requirement": "bc_min_service_static", "elastic_cap": 2.6,
                          "city_baseline_cap_mva": baseline_cap,
                          "line_scale": scale if component == "line" else 1.0,
                          "storage_scale": scale if component == "storage" else 1.0}
                summary, years, _, _, lines, _ = optimize(scheme, **kwargs)
                transformer_mw_price = summary["transformer_price_10k_per_purchased_mva"] / .95
                line_mw_price = LINE_CAPEX_10K * kwargs["line_scale"] / LINE_MW_2025
                storage_mw_price = summary["storage_price_10k_per_mwh"] * 2.15 * kwargs["storage_scale"]
                rows.append({"region_id": region_id, "scheme": scheme,
                             "changed_component": component, "component_price_scale": scale,
                             "transformer_effective_mw_price_10k": transformer_mw_price,
                             "line_channel_mw_price_10k": line_mw_price,
                             "storage_rated_mw_price_10k": storage_mw_price,
                             "transformer_to_line_price_ratio": transformer_mw_price / line_mw_price,
                             "transformer_to_storage_price_ratio": transformer_mw_price / storage_mw_price,
                             "objective_npv_10k": summary["objective_npv_10k"],
                             "mip_gap": summary["mip_gap"],
                             "new_lines": len(lines),
                             "total_new_storage_cabinets": sum(y["new_storage_modules"] for y in years),
                             "total_purchased_transformer_mva": sum(y["new_transformer_purchase_mva"] for y in years),
                             **{f"clr_{y['year']}": y["clr"] for y in years},
                             "source_status": "base_prices_source_examples;_price_scales_research_sensitivity"})
                print(region_id, scheme, component, scale, "DONE", flush=True)
    write_csv(rows, output)
    return rows


if __name__ == "__main__":
    run()
