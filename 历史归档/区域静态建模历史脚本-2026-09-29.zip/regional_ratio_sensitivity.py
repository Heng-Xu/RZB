"""围绕实际估价得到的两项成本比，重求邳州年度最优路径。"""

import json
from pathlib import Path

from .baseline_historical_proxy import build
from .city_mapping_audit import write_csv
from .incremental_cost import LINE_BASE_10K_PER_KM
from .joint_lifecycle_optimizer import cost_factors, load_inputs, solve_layer
from .regional_revision_run import OUTPUT, PIZHOU, LINE_KM, LINE_CAPACITY_MW, base_cost_ratios, pizhou_sample_fraction


DEST = OUTPUT / "ratio_sensitivity"
CASES = (("transformer_line_ratio_low", .8, 1.0),
         ("transformer_line_ratio_high", 1.2, 1.0),
         ("expansion_storage_ratio_low", 1.0, .8),
         ("expansion_storage_ratio_high", 1.0, 1.2))


def run(output_dir: Path = DEST) -> list[dict]:
    output_dir = Path(output_dir)
    sample = pizhou_sample_fraction()
    ratios = base_cost_ratios()
    station_baseline, _ = build()
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in station_baseline}
    _, scenes, durations, peaks, catalog, coefficients = load_inputs()
    summary_rows, annual_rows = [], []
    for case, line_ratio_factor, storage_ratio_factor in CASES:
        line_unit_cost = LINE_BASE_10K_PER_KM / line_ratio_factor
        storage_scale = 1.0 / storage_ratio_factor
        print("START", case, flush=True)
        stations, years, transfers, summary = solve_layer(
            PIZHOU, baseline, scenes, durations, peaks, catalog, coefficients,
            cost_factors(), 2.0, True, line_km=LINE_KM, line_unit_cost=line_unit_cost,
            storage_cost_scale=storage_scale, policy_peak_basis="annual",
            max_storage_modules=50, allow_capacity_release=True,
            prefer_reserve_at_equal_cost=True, canonicalize_tie_dispatch=True,
            contingency_service_fraction=None,
            regional_transfer={"initial_fraction": sample["initial_fraction"],
                               "maximum_fraction": .55,
                               "line_capacity_mw": LINE_CAPACITY_MW, "max_lines": 12})
        summary_rows.append({"case_id": case,
                             "transformer_line_lifecycle_ratio": ratios["transformer_to_line_lifecycle_ratio"] * line_ratio_factor,
                             "expansion_storage_lifecycle_ratio": ratios["expansion_to_storage_lifecycle_ratio"] * storage_ratio_factor,
                             "objective_npv_10k_cny": summary["objective_npv_10k_cny"],
                             "solver_status": summary["solver_status"]})
        write_csv(stations, output_dir / f"{case}_stations.csv")
        if transfers:
            write_csv(transfers, output_dir / f"{case}_transfers.csv")
        for year in years:
            annual_rows.append({"case_id": case, "year": year["year"],
                                "transformer_line_lifecycle_ratio": ratios["transformer_to_line_lifecycle_ratio"] * line_ratio_factor,
                                "expansion_storage_lifecycle_ratio": ratios["expansion_to_storage_lifecycle_ratio"] * storage_ratio_factor,
                                "capacity_mva": year["selected_capacity_mva"],
                                "clr": year["actual_clr"],
                                "storage_modules": year["storage_modules_in_service"],
                                "new_lines": year["line_built"],
                                "path_npv_10k_cny": summary["objective_npv_10k_cny"]})
        write_csv(summary_rows, output_dir / "summary.csv")
        write_csv(annual_rows, output_dir / "annual_sensitivity.csv")
        print("DONE", case, summary["objective_npv_10k_cny"], flush=True)
    (output_dir / "definition.json").write_text(
        json.dumps({"actual_baseline": ratios,
                    "change_rule": "hold_transformer_actual_reference_cost_fixed;_change_line_or_storage_cost_to_obtain_target_ratio",
                    "variation_factors_around_actual_ratio": [.8, 1.2]},
                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary_rows


if __name__ == "__main__":
    run()
