"""逐年刚性路径不可行时，给出可复算的跨年容量下界证据。"""

import json
from pathlib import Path

from . import joint_lifecycle_optimizer as optimizer
from .baseline_2021 import read_csv
from .hourly_source_profile import OUTPUT_DIR
from .regional_revision_run import pizhou_sample_fraction


OUTPUT = OUTPUT_DIR / "capacity_release_simulation/regional_2021_initial_2026_09_28/pizhou_pair_feasibility.json"


def run(output: Path = OUTPUT) -> dict:
    _, _, _, all_peaks, _, _ = optimizer.load_inputs()
    original_years = optimizer.YEARS
    optimizer.YEARS = (2022,)
    try:
        baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                    for r in read_csv(OUTPUT_DIR / "planning_2021_common_baseline_stations.csv")}
        _, scene, duration, peaks, catalog, coefficients = optimizer.load_inputs()
        sample = pizhou_sample_fraction()
        _, years, _, summary = optimizer.solve_layer(
            ("QX-00005", 110), baseline, scene, duration, peaks, catalog,
            coefficients, optimizer.cost_factors(), 2.0, True,
            line_km=3, line_unit_cost=33.6, line_extra_capex_10k_cny=6,
            policy_peak_basis="annual", max_storage_modules=50,
            allow_capacity_release=False, preserve_baseline_forward_margin=True,
            capacity_first=True,
            regional_transfer={"initial_fraction": sample["initial_fraction"],
                               "maximum_fraction": 1.0,
                               "line_capacity_mw": 7.491, "max_lines": 1,
                               "existing_capacity_mw": sample["sample_transfer_screen_mw"],
                               "existing_station_pair": ("BDZ-00027", "BDZ-00048"),
                               "new_line_station_pair": ("BDZ-00027", "BDZ-00048")})
        minimum_2022 = years[0]["selected_capacity_mva"]
        peak_2023 = all_peaks["QX-00005", 110, 2023]
        upper_2023 = 2 * peak_2023
        result = {"scope": "pair_limited_full_2021_margin_2022_capacity_minimum_vs_2023_rigid_cap",
                  "minimum_2022_capacity_mva": minimum_2022,
                  "2022_storage_modules_at_capacity_minimum": years[0]["storage_modules_in_service"],
                  "2022_new_lines_at_capacity_minimum": years[0]["line_built"],
                  "2023_synchronous_peak_mw": peak_2023,
                  "2023_max_capacity_at_R2_mva": upper_2023,
                  "capacity_gap_mva": round(minimum_2022 - upper_2023, 6),
                  "logical_result": "infeasible_if_capacity_non_decreasing" if minimum_2022 > upper_2023 else "not_proven_infeasible",
                  "solver_status": summary["solver_status"],
                  "note": "2021裕度全额保留是研究假设，50柜/站也是情景上限；本证明只对该组合成立"}
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return result
    finally:
        optimizer.YEARS = original_years


if __name__ == "__main__":
    print(run())
