# 弹性方案结果索引

本目录根部的 `pizhou_elastic_*` 是早期“弹性也允许 10 kV 联络”的历史试算；`elastic_transformer_storage_only/` 又错误地按“本站刚好够用”截断主变容量规格，导致 2025 年误报 13 柜储能。两者**均不能作为当前弹性结果**。根部 `pizhou_rigid_*` 仍是原始逐年负荷情景的刚性试算，但也使用过该容量预筛；在完整规格重算前，其成本比选仅供参考。

当前口径：刚性允许有限扩容、既有及新建 10 kV 联络、配储，容载比上限 2.0；弹性只允许扩容和配储，容载比研究上限 2.4。两方案同以 2021 年 1463.5 MVA 为仿真起点，2022 年起不减容。

| 负荷情景 | 刚性目录 | 当前弹性目录 |
| --- | --- | --- |
| 原表逐年负荷 | 本目录根部 `pizhou_rigid_*`，预筛试算 | `elastic_full_transformer_choices/` |
| 四年加权增长 | `weighted_4y_growth/pizhou_rigid_*`，预筛试算 | `weighted_4y_growth/elastic_full_transformer_choices/` |

每个目录中的 `annual_measures.csv` 为逐年措施和容载比，`summary.csv` 为成本与求解状态，`audit.json` 为独立静态复核。当前弹性子目录没有 `pizhou_elastic_transfers.csv`，逐年既有／新增转供、新线条数和线路投资全为零。原表定位和价格公式见 `研究报告/数据来源/2026-09-28_10kV线路与成本依据/核心原表单元格与模型公式核对.md`。

研究入口 `regional_rigid_elastic_research.py` 的默认设置已改为弹性禁用 10 kV 联络、主变完整规格集合，默认输出单独写入 `current_scopes/`。当前弹性两组结果已通过独立静态复核；刚性完整规格重算仍须完成，不能将根目录的成本差额写成最终结论。
