"""将当前增长约束路径整理为固定版式的逐年模型结果审查表。"""

from pathlib import Path

from .baseline_2021 import read_csv
from .hourly_source_profile import OUTPUT_DIR


NAME = {("QX-00005", 35): "邳州 35 kV", ("QX-00005", 110): "邳州 110 kV",
        ("QX-00007", 110): "市区 110 kV（29 站）"}


def render(output_dir: Path = OUTPUT_DIR) -> str:
    output_dir = Path(output_dir)
    baseline = {(r["study_region_id"], int(r["voltage_kv"])): r
                for r in read_csv(output_dir / "planning_2021_common_baseline_layers.csv")}
    summary = {(r["study_region_id"], int(r["voltage_kv"]), r["scheme"]): r
               for r in read_csv(output_dir / "growth_rebuild_layers.csv")}
    lines = [
        "# 增长约束模型逐年结果（2026-09-23 待审候选）", "",
        "状态：**允许结转真实备用的候选路径；不是最终推荐矩阵或工程实施方案。**", "",
        "列义：实际 R＝当年在役主变总容量／当年同步正向净峰；控制 R＝同容量／截至当年的滚动最大规划净峰。",
        "刚性控制 R≤2.0；弹性当前仿真上限为 2.4。新增容量、储能均指**该年增量**，储能另报年末累计柜数。",
        "2021 年为共同仿真起点，不等同于真实当年资产。金额为 2022—2025 年路径增量全寿命现值，单位万元。", "",
    ]
    for layer, label in NAME.items():
        b = baseline[layer]
        lines += [f"## {label}", "",
                  f"共同 2021 起点：{float(b['capacity_mva']):g} MVA；正向净峰 "
                  f"{float(b['net_forward_peak_mw']):.2f} MW；实际 R {float(b['simulated_clr']):.3f}。", ""]
        for scheme, title in (("rigid", "刚性"), ("elastic", "弹性")):
            years = [r for r in read_csv(output_dir / f"growth_rebuild_{scheme}_years.csv")
                     if (r["study_region_id"], int(r["voltage_kv"])) == layer]
            stations = [r for r in read_csv(output_dir / f"growth_rebuild_{scheme}_stations.csv")
                        if (r["study_region_id"], int(r["voltage_kv"])) == layer]
            ties = read_csv(output_dir / f"growth_rebuild_{scheme}_ties.csv")
            lines += [f"### {title}方案", "",
                      "| 年份 | 净峰 MW | 年末容量 MVA | 实际 R | 控制 R | 当年主变增容 MVA | 新增储能／累计储能 柜 | 10 kV 措施 |",
                      "| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |"]
            prior_line_built = 0
            for row in years:
                year = int(row["year"])
                selected = [s for s in stations if int(s["year"]) == year]
                added_capacity = sum(float(s["selected_capacity_mva"]) - float(s["prior_unit_1_mva"])
                                     - float(s["prior_unit_2_mva"]) for s in selected)
                added_storage = sum(int(s["new_storage_modules"]) for s in selected)
                active_ties = [t for t in ties if (t["study_region_id"], int(t["voltage_kv"])) == layer
                               and int(t["year"]) == year and t.get("scenario") == "forward"]
                measures = "；".join(f"{t['tie_id']} 转供 {float(t['transfer_mw']):.3f} MW" for t in active_ties)
                if int(row["line_built"]) and not prior_line_built:
                    measures += ("；" if measures else "") + "拟建线路投运"
                prior_line_built = int(row["line_built"])
                lines.append(
                    f"| {year} | {float(row['synchronous_forward_peak_mw']):.2f} | "
                    f"{float(row['selected_capacity_mva']):g} | {float(row['actual_clr']):.3f} | "
                    f"{float(row['policy_control_clr']):.3f} | +{added_capacity:g} | "
                    f"+{added_storage}／{int(row['storage_modules_in_service'])} | {measures or '无'} |"
                )
            s = summary[layer + (scheme,)]
            lines += ["", f"完整路径现值：**{float(s['objective_npv_10k_cny']):.2f} 万元**。", ""]
    lines += [
        "## 审查边界", "",
        "2023 年等低谷的实际 R 可能超过控制上限；刚性约束限制的是滚动规划净峰口径，不能把控制 R 当作当年实际 R。",
        "邳州 110 kV 基准刚性路径使用既有 T01；拟建墩振—河湾专用新线仅在既有联络受限等条件情景下成为备选。",
        "储能数量、离散主变档位、逐站基期备用保持与静态联络代理仍需审查；矩阵未放行，最终研究报告暂不撰写。", "",
    ]
    return "\n".join(lines)


def main() -> None:
    target = OUTPUT_DIR / "GROWTH-ANNUAL-MODEL-RESULTS-2026-09-23.md"
    target.write_text(render(), encoding="utf-8")
    print(target)


if __name__ == "__main__":
    main()
