"""整理增长驱动模型的条件结果；暂标为待审候选矩阵。"""

from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .planning_conditional_recommendation import build_recommendations


def main() -> None:
    rows, ranges = build_recommendations(OUTPUT_DIR / "growth_conditional_matrix.csv")
    for row in rows:
        row["status"] = "growth_rebuild_candidate_pending_matrix_acceptance"
    write_csv(rows, OUTPUT_DIR / "growth_conditional_recommendation_matrix.csv")
    write_csv(ranges, OUTPUT_DIR / "growth_conditional_recommendation_ranges.csv")
    print(f"增长模型整理 {len(rows)} 条待审条件行和 {len(ranges)} 条范围")


if __name__ == "__main__":
    main()
