"""邳州 110 kV 主变与储能价格联合仿真，核查方案翻转条件。"""

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .joint_lifecycle_optimizer import PIZHOU_110, cost_factors, load_inputs, solve_layer


def build_grid() -> list[dict]:
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in read_csv(OUTPUT_DIR / "planning_2021_common_baseline_stations.csv")}
    _, scenes, durations, peaks, catalog, coefficients = load_inputs()
    rows = []
    for transformer_scale in (.5, 1., 1.5, 2.):
        for storage_scale in (.5, 1., 1.5):
            costs = {}
            for scheme, cap in (("rigid", 2.), ("elastic", 2.4)):
                _, years, ties, summary = solve_layer(
                    PIZHOU_110, baseline, scenes, durations, peaks, catalog,
                    coefficients, cost_factors(), cap, scheme == "rigid",
                    include_new_line=scheme == "rigid",
                    transformer_cost_scale=transformer_scale,
                    storage_cost_scale=storage_scale,
                    capacity_first=False,
                    preserve_baseline_forward_margin=True,
                    policy_peak_basis="rolling_max",
                    max_storage_modules=50,
                    require_existing_tie_operation=False,
                )
                costs[scheme] = float(summary["objective_npv_10k_cny"])
                rows.append({
                    "transformer_cost_scale": transformer_scale,
                    "storage_cost_scale": storage_scale,
                    "scheme": scheme,
                    "four_year_path_lifecycle_npv_10k_cny": costs[scheme],
                    "2025_actual_clr": years[-1]["actual_clr"],
                    "2025_storage_modules": years[-1]["storage_modules_in_service"],
                    "2025_existing_tie_mw": round(sum(float(t["transfer_mw"]) for t in ties
                                                           if t["year"] == 2025 and t["scenario"] == "forward"), 6),
                    "scenario_status": "price_simulation_not_local_market_quote",
                })
            for row in rows[-2:]:
                row["cheaper_scheme"] = "rigid" if costs["rigid"] < costs["elastic"] - 1e-5 else (
                    "elastic" if costs["elastic"] < costs["rigid"] - 1e-5 else "cost_tie")
                row["rigid_minus_elastic_npv_10k_cny"] = round(costs["rigid"] - costs["elastic"], 8)
    return rows


def main() -> None:
    rows = build_grid()
    write_csv(rows, OUTPUT_DIR / "growth_cost_joint_grid_pizhou_110.csv")
    print(f"已写入 {len(rows)} 条邳州 110 kV 联合价格敏感性结果")


if __name__ == "__main__":
    main()
