"""核对增长驱动条件矩阵的路径、控制值和未核实新线使用情况。"""

import json
from collections import defaultdict

from .baseline_2021 import read_csv
from .hourly_source_profile import OUTPUT_DIR


def audit() -> dict:
    matrix = read_csv(OUTPUT_DIR / "growth_conditional_matrix.csv")
    scenarios = read_csv(OUTPUT_DIR / "growth_conditional_scenarios.csv")
    recommendations = read_csv(OUTPUT_DIR / "growth_conditional_recommendation_matrix.csv")
    feasibility = read_csv(OUTPUT_DIR / "growth_conditional_feasibility.csv")
    baselines = {scheme: {(r["study_region_id"], r["voltage_kv"], r["year"]): r
                          for r in read_csv(OUTPUT_DIR / f"growth_rebuild_{scheme}_years.csv")}
                 for scheme in ("rigid", "elastic")}
    by_case = defaultdict(list)
    for row in matrix:
        key = row["scenario_id"], row["study_region_id"], row["voltage_kv"], row["year"]
        by_case[key].append(row)
        cap = 2.0 if row["scheme"] == "rigid" else 2.4
        if float(row["policy_control_clr"]) > cap + 1e-6:
            raise ValueError(f"{key} 控制值超过方案上限")
        if abs(float(row["simulated_capacity_mva"]) / float(row["net_peak_mw"])
               - float(row["simulated_clr"])) > 1e-6:
            raise ValueError(f"{key} 实际年度容载比复算失败")
        if row["scenario_id"] == "base":
            base = baselines[row["scheme"]][key[1:]]
            if abs(float(row["simulated_capacity_mva"]) - float(base["selected_capacity_mva"])) > 1e-6:
                raise ValueError(f"{key} 基准路径与增长重建包不一致")
    expected = {(s["scenario_id"], region, voltage, str(year))
                for s in scenarios
                for region, voltage in (("QX-00005", "35"), ("QX-00005", "110"), ("QX-00007", "110"))
                for year in (2022, 2023, 2024, 2025)}
    keys = {(r["scenario_id"], r["study_region_id"], r["voltage_kv"], r["year"])
            for r in recommendations}
    missing = sorted(expected - keys)
    unverified_line_rows = [r for r in matrix if int(r["new_line_built"]) > 0]
    for row in recommendations:
        key = row["scenario_id"], row["study_region_id"], row["voltage_kv"], row["year"]
        paths = by_case[key]
        choice = row["preferred_scheme"]
        selected = paths if choice == "cost_tie" else [p for p in paths if p["scheme"] == choice.replace("_only_feasible", "")]
        if not selected:
            raise ValueError(f"{key} 推荐行无求解路径")
        ratios = [float(p["simulated_clr"]) for p in selected]
        if abs(min(ratios) - float(row["recommended_simulated_clr_min"])) > 1e-6 \
                or abs(max(ratios) - float(row["recommended_simulated_clr_max"])) > 1e-6:
            raise ValueError(f"{key} 推荐比值与设备路径不一致")
    result = {
        "scenario_count": len(scenarios),
        "annual_case_count": len(expected),
        "candidate_recommendation_rows": len(recommendations),
        "missing_case_count": len(missing),
        "missing_cases": missing,
        "unverified_new_line_selected_rows": len(unverified_line_rows),
        "infeasible_paths": [r for r in feasibility if r["status"] != "feasible_optimum"],
        "base_path_reconciliation": "PASS",
        "annual_actual_ratio_recalculation": "PASS",
        "rolling_policy_ratio_check": "PASS",
        "matrix_release_status": ("PENDING" if missing or unverified_line_rows else
                                  "INTERNAL_QA_PASSED_PENDING_PROJECT_ACCEPTANCE"),
    }
    return result


def main() -> None:
    result = audit()
    (OUTPUT_DIR / "growth_conditional_audit.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"增长矩阵校验：{result['candidate_recommendation_rows']} 行；{result['matrix_release_status']}")


if __name__ == "__main__":
    main()
