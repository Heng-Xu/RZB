"""校验增长约束重建包的容量、备用、措施与年度比值。"""

import json
from pathlib import Path

from .annual_no_tie_investment_submodel import storage_effective_power_per_module
from .baseline_2021 import read_csv
from .hourly_source_profile import OUTPUT_DIR
from .joint_lifecycle_optimizer import (
    DESIGNED_NEW_LINE_ID, EXISTING_OPERATIONAL_TIE, RIGID_2025_FORWARD_OPERATION_MW,
    load_inputs,
)
from .new_line_section_audit import designed_new_line_section


def validate(output_dir: Path = OUTPUT_DIR) -> dict:
    output_dir = Path(output_dir)
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in read_csv(output_dir / "planning_2021_common_baseline_stations.csv")}
    _, scenes, durations, _, _, _ = load_inputs()
    station_checks = year_checks = tie_checks = 0
    for scheme, cap in (("rigid", 2.0), ("elastic", 2.4)):
        station_rows = read_csv(output_dir / f"growth_rebuild_{scheme}_stations.csv")
        year_rows = read_csv(output_dir / f"growth_rebuild_{scheme}_years.csv")
        tie_path = output_dir / f"growth_rebuild_{scheme}_ties.csv"
        ties = read_csv(tie_path)
        if scheme == "elastic" and ties:
            raise ValueError("弹性方案不应调用 10 kV 联络")
        built = {(r["study_region_id"], int(r["voltage_kv"]), int(r["year"])): int(r["line_built"])
                 for r in year_rows}
        for t in ties:
            year = int(t["year"])
            if t["scenario"] != "forward" or t["study_region_id"] != "QX-00005" or int(t["voltage_kv"]) != 110:
                raise ValueError("增长包仅支持邳州 110 kV 正向年度转供")
            if t["tie_id"] == EXISTING_OPERATIONAL_TIE:
                donor = "BDZ-00027"
                seed = RIGID_2025_FORWARD_OPERATION_MW
            elif t["tie_id"] == DESIGNED_NEW_LINE_ID:
                donor = "BDZ-00027"
                seed = designed_new_line_section()["2025_feeder_stress_section_load_seed_mw"]
                if not built[t["study_region_id"], 110, year]:
                    raise ValueError("新线路未建设却发生转供")
            else:
                raise ValueError("出现未纳入模型的联络")
            key = ("QX-00005", 110, donor)
            expected = seed * (float(scenes[key, year]["estimated_station_forward_peak_mw"])
                               / float(scenes[key, 2025]["estimated_station_forward_peak_mw"]))
            if abs(float(t["transfer_mw"]) - expected) > 1e-5:
                raise ValueError(f"{t['tie_id']} {year} 不是完整可切区段：{t['transfer_mw']} != {expected}")
            tie_checks += 1
        previous_capacity = {}
        for r in station_rows:
            key = r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]
            year = int(r["year"])
            source = baseline[key]
            c0 = float(source["simulation_unit_1_mva"]) + float(source["simulation_unit_2_mva"])
            p0 = float(source["estimated_forward_peak_mw_2021"])
            c = float(r["selected_capacity_mva"])
            demand = float(r["forward_screen_mw"])
            modules = int(r["storage_modules_in_service"])
            duration = int(durations[key]["forward_d95_max_run_hours"])
            storage = modules * storage_effective_power_per_module(duration)
            outflow = sum(float(t["transfer_mw"]) for t in ties
                          if t["year"] == str(year) and t["scenario"] == "forward"
                          and t["donor_station_id"] == key[2])
            inflow = sum(float(t["transfer_mw"]) for t in ties
                         if t["year"] == str(year) and t["scenario"] == "forward"
                         and t["receiver_station_id"] == key[2])
            preserved_margin = .95 * c - demand + storage + outflow - inflow
            if preserved_margin + 1e-5 < .95 * c0 - p0:
                raise ValueError(f"{scheme} {key} {year} 基期备用未保持")
            if c + 1e-7 < previous_capacity.get(key, c0):
                raise ValueError(f"{scheme} {key} {year} 容量无依据下降")
            previous_capacity[key] = c
            station_checks += 1
        for r in year_rows:
            control_peak = float(r["policy_control_peak_mw"])
            actual_peak = float(r["synchronous_forward_peak_mw"])
            capacity = float(r["selected_capacity_mva"])
            if capacity / control_peak > cap + 1e-6:
                raise ValueError(f"{scheme} {r['study_region_id']} {r['voltage_kv']} {r['year']} 控制值超上限")
            if abs(capacity / actual_peak - float(r["actual_clr"])) > 1e-6:
                raise ValueError("当年实际容载比复算失败")
            year_checks += 1
    return {"status": "PASS", "station_year_checks": station_checks,
            "layer_year_checks": year_checks, "whole_section_tie_year_checks": tie_checks,
            "interpretation": "research_planning_static_constraints_not_full_power_flow"}


def main() -> None:
    result = validate()
    (OUTPUT_DIR / "growth_rebuild_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(result)


if __name__ == "__main__":
    main()
