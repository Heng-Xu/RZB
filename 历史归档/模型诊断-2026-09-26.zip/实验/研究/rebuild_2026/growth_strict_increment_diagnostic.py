"""独立诊断逐年全额增量约束；不覆盖上一版候选矩阵。"""

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .joint_lifecycle_optimizer import PIZHOU_110, cost_factors, load_inputs, solve_layer


def diagnose(output_dir=OUTPUT_DIR):
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in read_csv(output_dir / "planning_2021_common_baseline_stations.csv")}
    _, scenes, durations, peaks, catalog, coefficients = load_inputs()
    cases = [
        ("pizhou_35_rigid_2", ("QX-00005", 35), 2.0, False, False),
        ("pizhou_35_elastic_2p4", ("QX-00005", 35), 2.4, False, False),
        ("pizhou_110_rigid_2_new_allowed", PIZHOU_110, 2.0, True, True),
        ("pizhou_110_rigid_2_existing_only", PIZHOU_110, 2.0, True, False),
        ("pizhou_110_elastic_2p4", PIZHOU_110, 2.4, False, False),
        ("city_110_rigid_2", ("QX-00007", 110), 2.0, False, False),
        ("city_110_elastic_2p4", ("QX-00007", 110), 2.4, False, False),
        ("pizhou_110_relaxed_2p05_new_allowed", PIZHOU_110, 2.05, True, True),
        ("city_110_relaxed_2p1", ("QX-00007", 110), 2.1, False, False),
    ]
    results = []
    for case_id, layer, cap, use_tie, use_new in cases:
        common = dict(
            include_new_line=use_new, new_line_variant="designed_bus", line_km=3,
            tie_allowed=use_tie, existing_tie_allowed=True,
            preserve_baseline_forward_margin=True,
            preserve_prior_year_forward_margin=True,
            policy_peak_basis="rolling_max", max_storage_modules=50,
            require_existing_tie_operation=False,
            tie_year_basis="annual_station_scaled", canonicalize_tie_dispatch=True,
        )
        try:
            _, years, transfers, summary = solve_layer(
                layer, baseline, scenes, durations, peaks, catalog, coefficients,
                cost_factors(), cap, cap == 2.0, **common)
            results.append({
                "case_id": case_id, "study_region_id": layer[0], "voltage_kv": layer[1],
                "policy_cap": cap, "status": "FEASIBLE", "new_line_allowed": use_new,
                "2025_capacity_mva": years[-1]["selected_capacity_mva"],
                "2025_control_clr": years[-1]["policy_control_clr"],
                "2025_storage_cabinets": years[-1]["storage_modules_in_service"],
                "full_path_npv_10k_cny": summary["objective_npv_10k_cny"],
                "transfers": "; ".join(
                    f"{t['year']}:{t['tie_id']}:{float(t['transfer_mw']):.3f}MW" for t in transfers),
                "failure_detail": "",
            })
        except ValueError as exc:
            if "infeasible" not in str(exc).lower():
                raise
            results.append({
                "case_id": case_id, "study_region_id": layer[0], "voltage_kv": layer[1],
                "policy_cap": cap, "status": "INFEASIBLE", "new_line_allowed": use_new,
                "2025_capacity_mva": "", "2025_control_clr": "",
                "2025_storage_cabinets": "", "full_path_npv_10k_cny": "",
                "transfers": "", "failure_detail": str(exc),
            })
    write_csv(results, output_dir / "growth_strict_increment_feasibility.csv")
    return results


if __name__ == "__main__":
    for row in diagnose():
        print(row["case_id"], row["status"], row["2025_storage_cabinets"])
