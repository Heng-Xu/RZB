"""比较既有联络、新馈线和无转供的 2025 增长约束规划路径。"""

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .joint_lifecycle_optimizer import (
    DESIGNED_NEW_LINE_KM, PIZHOU_110, cost_factors, load_inputs, solve_layer,
)


def compare(output_dir=OUTPUT_DIR, annual_scope: bool = False):
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in read_csv(output_dir / "planning_2021_common_baseline_stations.csv")}
    _, scenes, durations, peaks, catalog, coefficients = load_inputs()
    rows, station_rows = [], []
    cases = [
        ("existing_and_new", True, True, 3.0, 0.0, 1.0, 1.0),
        ("existing_only", True, False, 3.0, 0.0, 1.0, 1.0),
        ("new_only_3km", False, True, 3.0, 0.0, 1.0, 1.0),
        ("no_transfer", False, False, 3.0, 0.0, 1.0, 1.0),
        ("both_90pct", True, True, 3.0, 0.0, 0.9, 1.0),
    ]
    cases += [(f"new_only_{km:g}km", False, True, km, 0.0, 1.0, 1.0)
              for km in (2.0, 4.0, 6.0, 8.0)]
    cases += [(f"new_only_3km_plus{extra:g}w", False, True, DESIGNED_NEW_LINE_KM, extra, 1.0, 1.0)
              for extra in (100.0, 200.0, 300.0)]
    cases += [(f"new_only_3km_coincidence_{factor:g}", False, True,
               DESIGNED_NEW_LINE_KM, 0.0, 1.0, factor)
              for factor in (0.4, 0.5, 0.6, 0.8, 0.9)]
    for case_id, existing, new, km, extra, transfer_scale, coincidence in cases:
        stations, years, ties, summary = solve_layer(
            PIZHOU_110, baseline, scenes, durations, peaks, catalog, coefficients,
            cost_factors(), 2.0, True, include_new_line=new,
            new_line_variant="designed_bus", line_km=km,
            line_extra_capex_10k_cny=extra,
            tie_allowed=True, existing_tie_allowed=existing,
            tie_transfer_limit_scale=transfer_scale,
            new_line_section_coincidence=coincidence,
            preserve_baseline_forward_margin=True, policy_peak_basis="rolling_max",
            max_storage_modules=50, require_existing_tie_operation=False,
            tie_year_basis="annual_station_scaled" if annual_scope else "2025_only",
            canonicalize_tie_dispatch=annual_scope,
            preserve_prior_year_forward_margin=False,
        )
        final = years[-1]
        rows.append({
            "case_id": case_id, "existing_tie_available": existing,
            "new_line_candidate_available": new, "new_line_assumed_km": km,
            "new_line_extra_capex_10k_cny": extra,
            "transfer_limit_scale": transfer_scale,
            "new_line_section_coincidence": coincidence,
            "existing_tie_transfer_mw": round(sum(t["transfer_mw"] for t in ties if t["tie_id"] == "T01"), 8),
            "new_line_transfer_mw": round(sum(t["transfer_mw"] for t in ties if t["tie_id"] == "SIM-NEW-DZHEN-RIVER-BUS"), 8),
            "new_line_built": final["line_built"],
            "2025_capacity_mva": final["selected_capacity_mva"],
            "2025_storage_modules": final["storage_modules_in_service"],
            "2025_policy_control_clr": final["policy_control_clr"],
            "lifecycle_npv_10k_cny": summary["objective_npv_10k_cny"],
            "technical_scope": summary["technical_scope"],
        })
        for station in stations:
            if station["year"] == 2025 and station["model_station_id"] in ("BDZ-00027", "BDZ-00048"):
                station_rows.append({"case_id": case_id, **station})
    suffix = "_annual" if annual_scope else ""
    write_csv(rows, output_dir / f"growth_new_line_comparison{suffix}.csv")
    write_csv(station_rows, output_dir / f"growth_new_line_station_comparison{suffix}.csv")
    return rows


if __name__ == "__main__":
    result = compare()
    for row in result:
        print(row["case_id"], row["new_line_built"], row["lifecycle_npv_10k_cny"])
