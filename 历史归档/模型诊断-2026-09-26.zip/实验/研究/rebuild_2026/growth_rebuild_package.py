"""按已确认的基期备用保持与滚动规划净峰，生成替代旧矩阵的规划核查包。"""

from pathlib import Path

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .incremental_cost import LINE_BASE_10K_PER_KM, LINE_HIGH_10K_PER_KM
from .joint_lifecycle_optimizer import (
    DESIGNED_NEW_LINE_KM, DESIGNED_NEW_LINE_LIMIT_MW, NEW_LINE_FEEDERS, NEW_LINE_KM,
    PIZHOU_110, cost_factors,
    load_inputs, solve_layer,
)
from .new_line_section_audit import designed_new_line_section
from .pizhou_existing_ties import build_feeder_headroom


def run_growth_rebuild(output_dir: Path = OUTPUT_DIR,
                       strict_annual_increment: bool = False) -> list[dict]:
    output_dir = Path(output_dir)
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in read_csv(output_dir / "planning_2021_common_baseline_stations.csv")}
    _, scenes, durations, peaks, catalog, coefficients = load_inputs()
    layer_keys = sorted({station[:2] for station in baseline})
    summaries = []
    pending = {}
    for scheme, cap, allow_tie in (("rigid", 2.0, True), ("elastic", 2.4, False)):
        stations, years, ties = [], [], []
        for layer in layer_keys:
            result = solve_layer(
                layer, baseline, scenes, durations, peaks, catalog, coefficients,
                cost_factors(), cap, scheme == "rigid",
                include_new_line=allow_tie and layer == PIZHOU_110,
                new_line_variant="designed_bus",
                line_km=DESIGNED_NEW_LINE_KM,
                tie_allowed=allow_tie,
                capacity_first=False,
                preserve_baseline_forward_margin=True,
                policy_peak_basis="rolling_max",
                max_storage_modules=50,
                require_existing_tie_operation=False,
                tie_year_basis="annual_station_scaled",
                canonicalize_tie_dispatch=True,
                preserve_prior_year_forward_margin=strict_annual_increment,
            )
            layer_stations, layer_years, layer_ties, summary = result
            stations.extend(layer_stations)
            years.extend(layer_years)
            ties.extend(layer_ties)
            summary["model_status"] = "growth_reserve_rebuild_pre_matrix_acceptance"
            summaries.append(summary)
        pending[scheme] = stations, years, ties
    for scheme, (stations, years, ties) in pending.items():
        write_csv(stations, output_dir / f"growth_rebuild_{scheme}_stations.csv")
        write_csv(years, output_dir / f"growth_rebuild_{scheme}_years.csv")
        if ties:
            write_csv(ties, output_dir / f"growth_rebuild_{scheme}_ties.csv")
        else:
            (output_dir / f"growth_rebuild_{scheme}_ties.csv").write_text(
                "study_region_id,voltage_kv,year,scenario,tie_id,transfer_mw\n", encoding="utf-8-sig")
    write_csv(summaries, output_dir / "growth_rebuild_layers.csv")

    feeders = {r["feeder_id"]: r for r in build_feeder_headroom()}
    donor, receiver = (feeders[feeder_id] for feeder_id in NEW_LINE_FEEDERS)
    max_source_transfer = min(float(donor["current_equivalent_active_power_mw"]),
                              float(receiver["receiving_current_headroom_mw"]), 4.0)
    donor_key = ("QX-00005", 110, "BDZ-00027")
    donor_baseline = baseline[donor_key]
    donor_2025 = next(r for r in read_csv(output_dir / "growth_rebuild_rigid_stations.csv")
                      if r["study_region_id"] == donor_key[0] and int(r["voltage_kv"]) == donor_key[1]
                      and r["model_station_id"] == donor_key[2] and int(r["year"]) == 2025)
    c0 = float(donor_baseline["simulation_unit_1_mva"]) + float(donor_baseline["simulation_unit_2_mva"])
    p0 = float(donor_baseline["estimated_forward_peak_mw_2021"])
    donor_reserve_gap = max(0.0, float(donor_2025["forward_screen_mw"]) + .95 * c0 - p0
                            - .95 * float(donor_2025["selected_capacity_mva"]))
    new_section = designed_new_line_section()
    write_csv([{
        "candidate_id": "NEWTIE-BDZ00027-BDZ00048-01",
        "donor_feeder_id": NEW_LINE_FEEDERS[0],
        "receiver_feeder_id": NEW_LINE_FEEDERS[1],
        "assumed_length_km": NEW_LINE_KM,
        "baseline_line_only_capex_10k_cny": round(NEW_LINE_KM * LINE_BASE_10K_PER_KM, 6),
        "high_line_only_capex_10k_cny": round(NEW_LINE_KM * LINE_HIGH_10K_PER_KM, 6),
        "source_end_static_transfer_upper_mw": round(max_source_transfer, 6),
        "2025_growth_reserve_gap_at_selected_donor_capacity_before_transfer_mw": round(donor_reserve_gap, 6),
        "can_cover_that_gap_alone": "YES" if max_source_transfer >= donor_reserve_gap else "NO",
        "selected_in_growth_rebuild": "NO",
        "endpoint_status": "proposed_feeder_pair_only_exact_poles_and_section_not_mapped",
        "cost_scope": "line_only_excludes_switch_and_protection",
        "evidence": "10kv_case/new_tie_candidates.csv; feeder_master.csv; per_line_source_PDFs",
    }, {
        "candidate_id": new_section["candidate_id"],
        "donor_feeder_id": new_section["donor_feeder_id"],
        "receiver_feeder_id": "SIM-RIVER-NEW-FEEDER",
        "assumed_length_km": DESIGNED_NEW_LINE_KM,
        "baseline_line_only_capex_10k_cny": round(DESIGNED_NEW_LINE_KM * LINE_BASE_10K_PER_KM, 6),
        "high_line_only_capex_10k_cny": round(DESIGNED_NEW_LINE_KM * LINE_HIGH_10K_PER_KM, 6),
        "source_end_static_transfer_upper_mw": round(min(
            float(feeders[new_section["donor_feeder_id"]]["current_equivalent_active_power_mw"]),
            DESIGNED_NEW_LINE_LIMIT_MW), 6),
        "2025_growth_reserve_gap_at_selected_donor_capacity_before_transfer_mw": round(donor_reserve_gap, 6),
        "can_cover_that_gap_alone": "YES" if new_section["2025_feeder_stress_section_load_seed_mw"] >= donor_reserve_gap else "NO",
        "selected_in_growth_rebuild": "YES" if any(int(r["line_built"]) for r in read_csv(output_dir / "growth_rebuild_rigid_years.csv")
                                              if r["study_region_id"] == "QX-00005" and r["voltage_kv"] == "110") else "NO",
        "endpoint_status": "designed_new_isolation_switch_and_new_station_feeder_route_unmeasured",
        "cost_scope": "line_only_excludes_new_switch_bus_bay_and_protection",
        "evidence": "new_line_section_audit.py; 邳州_10kV墩振线.pdf; base_debug_edges.csv",
    }], output_dir / "growth_rebuild_new_line_screen.csv")
    write_csv([new_section], output_dir / "growth_rebuild_new_line_section_audit.csv")
    return summaries


def main() -> None:
    rows = run_growth_rebuild()
    print(f"已生成 {len(rows)} 个增长约束方案层结果；矩阵仍待核验")


if __name__ == "__main__":
    main()
