"""拆解净峰增长、离散主变增量与实际容载比回落。"""

from collections import defaultdict

from .baseline_2021 import read_csv
from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR


def audit(output_dir=OUTPUT_DIR):
    baseline = {(r["study_region_id"], int(r["voltage_kv"]), r["model_station_id"]): r
                for r in read_csv(output_dir / "planning_2021_common_baseline_stations.csv")}
    base_layers = {(r["study_region_id"], int(r["voltage_kv"])): r
                   for r in read_csv(output_dir / "planning_2021_common_baseline_layers.csv")}
    year_rows = {(r["study_region_id"], int(r["voltage_kv"]), int(r["year"])): r
                 for r in read_csv(output_dir / "growth_rebuild_rigid_years.csv")}
    stations, layers = [], []
    grouped = defaultdict(list)
    for row in read_csv(output_dir / "growth_rebuild_rigid_stations.csv"):
        key = row["study_region_id"], int(row["voltage_kv"]), row["model_station_id"]
        base = baseline[key]
        delta_capacity = float(row["selected_capacity_mva"]) - sum(
            float(base[f"simulation_unit_{i}_mva"]) for i in (1, 2))
        delta_station_peak = float(row["forward_screen_mw"]) - float(base["estimated_forward_peak_mw_2021"])
        result = {
            "study_region_id": key[0], "voltage_kv": key[1], "year": int(row["year"]),
            "model_station_id": key[2],
            "station_forward_peak_growth_mw": round(delta_station_peak, 8),
            "selected_capacity_growth_mva": round(delta_capacity, 8),
            "capacity_growth_minus_forward_growth_div_095_mva": round(delta_capacity - delta_station_peak / .95, 8),
            "storage_modules_in_service": int(row["storage_modules_in_service"]),
        }
        stations.append(result)
        grouped[key[:2] + (int(row["year"]),)].append(result)
    for key, records in sorted(grouped.items()):
        base = base_layers[key[:2]]
        year = year_rows[key]
        layers.append({
            "study_region_id": key[0], "voltage_kv": key[1], "year": key[2],
            "2021_actual_clr": float(base["simulated_clr"]),
            "year_actual_clr": float(year["actual_clr"]),
            "synchronous_forward_peak_growth_mw": round(
                float(year["synchronous_forward_peak_mw"]) - float(base["net_forward_peak_mw"]), 8),
            "sum_station_peak_growth_mw": round(sum(r["station_forward_peak_growth_mw"] for r in records), 8),
            "capacity_growth_mva": round(sum(r["selected_capacity_growth_mva"] for r in records), 8),
            "capacity_step_excess_vs_station_growth_mva": round(sum(
                r["capacity_growth_minus_forward_growth_div_095_mva"] for r in records), 8),
            "interpretation": "arithmetic_diagnostic_not_causal_allocation_discrete_units_storage_reverse_constraints",
        })
    write_csv(stations, output_dir / "growth_capacity_step_stations.csv")
    write_csv(layers, output_dir / "growth_capacity_step_layers.csv")
    return layers


if __name__ == "__main__":
    for row in audit():
        print(row["study_region_id"], row["voltage_kv"], row["year"],
              row["capacity_step_excess_vs_station_growth_mva"])
