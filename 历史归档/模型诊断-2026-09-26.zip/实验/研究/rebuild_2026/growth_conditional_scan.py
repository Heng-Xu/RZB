"""在增长驱动模型上重跑条件情景；输出仍需工程与模型审查。"""

from .city_mapping_audit import write_csv
from .hourly_source_profile import OUTPUT_DIR
from .planning_conditional_scan import build_scan


def main() -> None:
    matrix, scenarios = build_scan(growth_rebuild=True)
    write_csv(matrix, OUTPUT_DIR / "growth_conditional_matrix.csv")
    write_csv(scenarios, OUTPUT_DIR / "growth_conditional_scenarios.csv")
    print(f"增长模型写入 {len(scenarios)} 个条件情景、{len(matrix)} 条年度方案")


if __name__ == "__main__":
    main()
